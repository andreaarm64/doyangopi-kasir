package com.doyangopi.kasir.util

object PriceCalculator {

    const val EXTRA_SHOT_PRICE = 4000
    const val UPSIZE_PRICE     = 6000
    const val OATMILK_PRICE    = 3000
    const val CARAMEL_SAUCE_PRICE     = 3000
    const val BUTTERSCOTCH_SAUCE_PRICE = 5000

    // ── Menu master list (sesuai menu board terbaru) ──────────────────────
    val ALL_MENUS = listOf(
        // Coffee Series
        "Kopsus Aren (Ice)",          "Kopsus Aren (Hot)",
        "Kopi Latte (Ice)",           "Kopi Latte (Hot)",
        "Kopi Spanish Latte (Ice)",   "Kopi Spanish Latte (Hot)",
        "Kopi Mocca (Ice)",           "Kopi Mocca (Hot)",
        "Kopi Hitam (Ice)",           "Kopi Hitam (Hot)",
        "Kopi Buttericano (Ice)",     "Kopi Buttericano (Hot)",
        "Kopi Caramicano (Ice)",      "Kopi Caramicano (Hot)",
        "Kopsus Caramel (Ice)",       "Kopsus Caramel (Hot)",
        "Kopsus Butterscotch (Ice)",  "Kopsus Butterscotch (Hot)",
        "Mokapot (Ice)",              "Mokapot (Hot)",
        // Non-Coffee Series
        "Matcha Latte (Ice)",         "Matcha Latte (Hot)",
        "Choco Latte (Ice)",          "Choco Latte (Hot)",
        "Red Velvet Latte (Ice)",     "Red Velvet Latte (Hot)"
    )

    fun getBasePrice(menu: String): Int = when {
        menu.startsWith("Kopsus Aren")           -> 10000
        menu.startsWith("Kopi Latte")             -> 10000
        menu.startsWith("Kopi Spanish Latte")      -> 12000
        menu.startsWith("Kopi Mocca")              -> 15000
        menu.startsWith("Kopi Hitam")              -> 10000   // diminta tetap 10k (bukan 15k di banner)
        menu.startsWith("Kopi Buttericano")        -> 12000
        menu.startsWith("Kopi Caramicano")         -> 12000
        menu.startsWith("Kopsus Caramel")          -> 12000
        menu.startsWith("Kopsus Butterscotch")     -> 15000
        menu.startsWith("Mokapot")                 -> 15000
        menu.startsWith("Matcha Latte")            -> 15000
        menu.startsWith("Choco Latte")              -> 15000
        menu.startsWith("Red Velvet Latte")        -> 15000
        else                                        -> 0
    }

    fun isMokapot(menu: String) = menu.startsWith("Mokapot")
    fun isHot(menu: String)     = menu.endsWith("(Hot)")

    // Mokapot, Matcha Latte, Choco Latte & Red Velvet Latte tidak ada extra shot
    fun allowsExtraShot(menu: String) =
        !isMokapot(menu) &&
        !menu.startsWith("Matcha Latte") &&
        !menu.startsWith("Choco Latte") &&
        !menu.startsWith("Red Velvet Latte")

    // ── Add-on (berlaku untuk semua menu) ─────────────────────────────────
    data class AddOn(val label: String, val price: Int)

    val ADD_ONS = listOf(
        AddOn("Upsize (16oz)",       UPSIZE_PRICE),
        AddOn("Oatmilk",             OATMILK_PRICE),
        AddOn("Caramel Sauce",       CARAMEL_SAUCE_PRICE),
        AddOn("Butterscotch Sauce",  BUTTERSCOTCH_SAUCE_PRICE)
    )

    fun addOnsPrice(addOns: List<String>): Int =
        addOns.sumOf { label -> ADD_ONS.find { it.label == label }?.price ?: 0 }

    fun pricePerItem(menu: String, extraShot: Boolean, addOns: List<String> = emptyList()): Int {
        val extra = if (extraShot && allowsExtraShot(menu)) EXTRA_SHOT_PRICE else 0
        return getBasePrice(menu) + extra + addOnsPrice(addOns)
    }

    fun calculate(menu: String, extraShot: Boolean, qty: Int, addOns: List<String> = emptyList()): Int =
        pricePerItem(menu, extraShot, addOns) * qty

    fun format(price: Int): String =
        "Rp " + String.format("%,d", price).replace(',', '.')
}
