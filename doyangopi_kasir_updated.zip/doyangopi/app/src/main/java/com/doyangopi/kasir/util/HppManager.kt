package com.doyangopi.kasir.util

import android.content.Context

/**
 * Menyimpan HPP (Harga Pokok Penjualan / harga modal) per menu & per add-on.
 * Disimpan terpisah di SharedPreferences — tidak menyentuh database transaksi.
 */
class HppManager(context: Context) {

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    companion object {
        private const val PREFS_NAME  = "doyangopi_hpp"
        private const val KEY_PREFIX  = "hpp_"
        private const val ADDON_PREFIX = "addon_hpp_"

        // Estimasi modal add-on (bisa diubah manual di layar HPP).
        // Upsize: tambahan cup 16oz + porsi bahan lebih banyak.
        // Oatmilk: substitusi susu, harga per porsi oat milk relatif mahal.
        // Sauce: harga pump sauce botolan per porsi.
        val DEFAULT_ADDON_HPP = mapOf(
            "Upsize (16oz)"      to 1500,
            "Oatmilk"            to 2000,
            "Caramel Sauce"      to 1000,
            "Butterscotch Sauce" to 1200
        )
    }

    // ── Menu ──
    fun getHpp(menu: String): Int = prefs.getInt(KEY_PREFIX + menu, 0)

    fun setHpp(menu: String, value: Int) {
        prefs.edit().putInt(KEY_PREFIX + menu, value).apply()
    }

    fun setAll(values: Map<String, Int>) {
        val editor = prefs.edit()
        values.forEach { (menu, value) -> editor.putInt(KEY_PREFIX + menu, value) }
        editor.apply()
    }

    fun getAll(menus: List<String>): Map<String, Int> =
        menus.associateWith { getHpp(it) }

    /** Menu yang HPP-nya belum diisi (masih 0). */
    fun unconfiguredMenus(menus: List<String>): List<String> =
        menus.filter { getHpp(it) == 0 }

    // ── Add-On ──
    fun getAddOnHpp(label: String): Int =
        prefs.getInt(ADDON_PREFIX + label, DEFAULT_ADDON_HPP[label] ?: 0)

    fun setAddOnHpp(label: String, value: Int) {
        prefs.edit().putInt(ADDON_PREFIX + label, value).apply()
    }

    fun setAllAddOns(values: Map<String, Int>) {
        val editor = prefs.edit()
        values.forEach { (label, value) -> editor.putInt(ADDON_PREFIX + label, value) }
        editor.apply()
    }

    fun getAllAddOns(labels: List<String>): Map<String, Int> =
        labels.associateWith { getAddOnHpp(it) }
}
