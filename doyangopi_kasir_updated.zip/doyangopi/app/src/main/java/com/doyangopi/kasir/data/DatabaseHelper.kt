package com.doyangopi.kasir.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.util.Calendar

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {

    companion object {
        private const val DB_NAME    = "doyangopi.db"
        private const val DB_VERSION = 4   // v4: tambah kolom add-ons

        // ── Transactions ──
        const val TABLE          = "transactions"
        const val COL_ID         = "id"
        const val COL_QUEUE      = "queue_number"
        const val COL_MENU       = "menu"
        const val COL_KEMANISAN  = "kemanisan"
        const val COL_LEVEL_ES   = "level_es"
        const val COL_EXTRA_SHOT = "extra_shot"
        const val COL_QTY        = "qty"
        const val COL_NOTES      = "notes"
        const val COL_PRICE_ITEM = "price_per_item"
        const val COL_TOTAL      = "total_price"
        const val COL_PAYMENT    = "payment_method"
        const val COL_TIMESTAMP  = "timestamp"
        const val COL_ADDONS     = "addons"

        // ── Expenses ──
        const val EXP_TABLE     = "expenses"
        const val EXP_ID        = "id"
        const val EXP_DATE      = "date"
        const val EXP_CATEGORY  = "category"
        const val EXP_DESC      = "description"
        const val EXP_AMOUNT    = "amount"
        const val EXP_TIMESTAMP = "timestamp"
    }

    private val createTransactionsSQL = """
        CREATE TABLE $TABLE (
            $COL_ID         INTEGER PRIMARY KEY AUTOINCREMENT,
            $COL_QUEUE      TEXT    NOT NULL,
            $COL_MENU       TEXT    NOT NULL,
            $COL_KEMANISAN  TEXT    NOT NULL,
            $COL_LEVEL_ES   TEXT    NOT NULL,
            $COL_EXTRA_SHOT INTEGER NOT NULL DEFAULT 0,
            $COL_QTY        INTEGER NOT NULL,
            $COL_NOTES      TEXT,
            $COL_PRICE_ITEM INTEGER NOT NULL,
            $COL_TOTAL      INTEGER NOT NULL,
            $COL_PAYMENT    TEXT    NOT NULL DEFAULT 'Cash',
            $COL_TIMESTAMP  INTEGER NOT NULL,
            $COL_ADDONS     TEXT    NOT NULL DEFAULT ''
        )
    """.trimIndent()

    private val createExpensesSQL = """
        CREATE TABLE $EXP_TABLE (
            $EXP_ID        INTEGER PRIMARY KEY AUTOINCREMENT,
            $EXP_DATE      TEXT    NOT NULL,
            $EXP_CATEGORY  TEXT    NOT NULL,
            $EXP_DESC      TEXT    NOT NULL,
            $EXP_AMOUNT    INTEGER NOT NULL,
            $EXP_TIMESTAMP INTEGER NOT NULL
        )
    """.trimIndent()

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(createTransactionsSQL)
        db.execSQL(createExpensesSQL)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            // Schema lama sangat berbeda, reset semua
            db.execSQL("DROP TABLE IF EXISTS $TABLE")
            db.execSQL("DROP TABLE IF EXISTS $EXP_TABLE")
            onCreate(db)
            return
        }
        if (oldVersion < 3) {
            // v2 → v3: JAGA data transaksi, cukup tambah tabel expenses
            db.execSQL("DROP TABLE IF EXISTS $EXP_TABLE")
            db.execSQL(createExpensesSQL)
        }
        if (oldVersion < 4) {
            // v3 → v4: JAGA semua data, cukup tambah kolom add-ons
            db.execSQL("ALTER TABLE $TABLE ADD COLUMN $COL_ADDONS TEXT NOT NULL DEFAULT ''")
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  TRANSACTIONS
    // ══════════════════════════════════════════════════════════════

    fun insert(t: Transaction): Long {
        val cv = ContentValues().apply {
            put(COL_QUEUE,      t.queueNumber)
            put(COL_MENU,       t.menu)
            put(COL_KEMANISAN,  t.kemanisan)
            put(COL_LEVEL_ES,   t.levelEs)
            put(COL_EXTRA_SHOT, if (t.extraShot) 1 else 0)
            put(COL_QTY,        t.qty)
            put(COL_NOTES,      t.notes)
            put(COL_PRICE_ITEM, t.pricePerItem)
            put(COL_TOTAL,      t.totalPrice)
            put(COL_PAYMENT,    t.paymentMethod)
            put(COL_TIMESTAMP,  t.timestamp)
            put(COL_ADDONS,     t.addOns.joinToString("|"))
        }
        return writableDatabase.insert(TABLE, null, cv)
    }

    fun updateTransaction(t: Transaction): Boolean {
        val cv = android.content.ContentValues().apply {
            put(COL_MENU,       t.menu)
            put(COL_KEMANISAN,  t.kemanisan)
            put(COL_LEVEL_ES,   t.levelEs)
            put(COL_EXTRA_SHOT, if (t.extraShot) 1 else 0)
            put(COL_QTY,        t.qty)
            put(COL_NOTES,      t.notes)
            put(COL_PRICE_ITEM, t.pricePerItem)
            put(COL_TOTAL,      t.totalPrice)
            put(COL_PAYMENT,    t.paymentMethod)
            put(COL_ADDONS,     t.addOns.joinToString("|"))
        }
        return writableDatabase.update(TABLE, cv, "$COL_ID = ?", arrayOf(t.id.toString())) > 0
    }

    fun deleteTransaction(id: Long): Boolean =
        writableDatabase.delete(TABLE, "$COL_ID = ?", arrayOf(id.toString())) > 0

    private fun startOfDay(cal: Calendar = Calendar.getInstance()): Long =
        cal.apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0);      set(Calendar.MILLISECOND, 0)
        }.timeInMillis

    fun getTodayTransactions()  = queryRange(startOfDay(),
        Calendar.getInstance().apply { timeInMillis = startOfDay(); add(Calendar.DAY_OF_MONTH, 1) }.timeInMillis)

    fun getWeekTransactions(): List<Transaction> {
        val cal = Calendar.getInstance()
        while (cal.get(Calendar.DAY_OF_WEEK) != Calendar.MONDAY) cal.add(Calendar.DAY_OF_MONTH, -1)
        val start = startOfDay(cal)
        cal.add(Calendar.DAY_OF_MONTH, 7)
        return queryRange(start, cal.timeInMillis)
    }

    fun getMonthTransactions(): List<Transaction> {
        val cal = Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1) }
        val start = startOfDay(cal)
        cal.add(Calendar.MONTH, 1)
        return queryRange(start, cal.timeInMillis)
    }

    fun queryRange(start: Long, end: Long): List<Transaction> {
        val cursor = readableDatabase.query(
            TABLE, null,
            "$COL_TIMESTAMP >= ? AND $COL_TIMESTAMP < ?",
            arrayOf(start.toString(), end.toString()),
            null, null, "$COL_TIMESTAMP ASC"
        )
        val list = mutableListOf<Transaction>()
        cursor.use {
            while (it.moveToNext()) list.add(Transaction(
                id            = it.getLong(it.getColumnIndexOrThrow(COL_ID)),
                queueNumber   = it.getString(it.getColumnIndexOrThrow(COL_QUEUE)),
                menu          = it.getString(it.getColumnIndexOrThrow(COL_MENU)),
                kemanisan     = it.getString(it.getColumnIndexOrThrow(COL_KEMANISAN)),
                levelEs       = it.getString(it.getColumnIndexOrThrow(COL_LEVEL_ES)),
                extraShot     = it.getInt(it.getColumnIndexOrThrow(COL_EXTRA_SHOT)) == 1,
                qty           = it.getInt(it.getColumnIndexOrThrow(COL_QTY)),
                notes         = it.getString(it.getColumnIndexOrThrow(COL_NOTES)) ?: "",
                pricePerItem  = it.getInt(it.getColumnIndexOrThrow(COL_PRICE_ITEM)),
                totalPrice    = it.getInt(it.getColumnIndexOrThrow(COL_TOTAL)),
                paymentMethod = it.getString(it.getColumnIndexOrThrow(COL_PAYMENT)) ?: "Cash",
                timestamp     = it.getLong(it.getColumnIndexOrThrow(COL_TIMESTAMP)),
                addOns        = (it.getString(it.getColumnIndexOrThrow(COL_ADDONS)) ?: "")
                                    .split("|").filter { s -> s.isNotBlank() }
            ))
        }
        return list
    }

    fun nextQueueNumber(): String {
        val cal = Calendar.getInstance()
        val monthLetter = ('A' + cal.get(Calendar.MONTH)).toString()
        cal.set(Calendar.DAY_OF_MONTH, 1)
        val start = startOfDay(cal)
        val cursor = readableDatabase.rawQuery(
            "SELECT COUNT(DISTINCT $COL_QUEUE) FROM $TABLE WHERE $COL_TIMESTAMP >= ?",
            arrayOf(start.toString())
        )
        cursor.use { it.moveToFirst(); return "$monthLetter${(it.getInt(0) + 1).toString().padStart(3, '0')}" }
    }

    // ══════════════════════════════════════════════════════════════
    //  EXPENSES
    // ══════════════════════════════════════════════════════════════

    fun insertExpense(e: Expense): Long {
        val cv = ContentValues().apply {
            put(EXP_DATE,      e.date)
            put(EXP_CATEGORY,  e.category)
            put(EXP_DESC,      e.description)
            put(EXP_AMOUNT,    e.amount)
            put(EXP_TIMESTAMP, e.timestamp)
        }
        return writableDatabase.insert(EXP_TABLE, null, cv)
    }

    fun deleteExpense(id: Long): Boolean =
        writableDatabase.delete(EXP_TABLE, "$EXP_ID = ?", arrayOf(id.toString())) > 0

    fun getExpensesForPeriod(start: Long, end: Long): List<Expense> {
        val cursor = readableDatabase.query(
            EXP_TABLE, null,
            "$EXP_TIMESTAMP >= ? AND $EXP_TIMESTAMP < ?",
            arrayOf(start.toString(), end.toString()),
            null, null, "$EXP_TIMESTAMP ASC"
        )
        val list = mutableListOf<Expense>()
        cursor.use {
            while (it.moveToNext()) list.add(Expense(
                id          = it.getLong(it.getColumnIndexOrThrow(EXP_ID)),
                date        = it.getString(it.getColumnIndexOrThrow(EXP_DATE)),
                category    = it.getString(it.getColumnIndexOrThrow(EXP_CATEGORY)),
                description = it.getString(it.getColumnIndexOrThrow(EXP_DESC)),
                amount      = it.getInt(it.getColumnIndexOrThrow(EXP_AMOUNT)),
                timestamp   = it.getLong(it.getColumnIndexOrThrow(EXP_TIMESTAMP))
            ))
        }
        return list
    }

    fun getTodayExpenses()  = getExpensesForPeriod(startOfDay(),
        Calendar.getInstance().apply { timeInMillis = startOfDay(); add(Calendar.DAY_OF_MONTH, 1) }.timeInMillis)

    fun getWeekExpenses(): List<Expense> {
        val cal = Calendar.getInstance()
        while (cal.get(Calendar.DAY_OF_WEEK) != Calendar.MONDAY) cal.add(Calendar.DAY_OF_MONTH, -1)
        val start = startOfDay(cal)
        cal.add(Calendar.DAY_OF_MONTH, 7)
        return getExpensesForPeriod(start, cal.timeInMillis)
    }

    fun getMonthExpenses(): List<Expense> {
        val cal = Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1) }
        val start = startOfDay(cal)
        cal.add(Calendar.MONTH, 1)
        return getExpensesForPeriod(start, cal.timeInMillis)
    }
}
