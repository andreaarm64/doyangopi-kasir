package com.doyangopi.kasir

import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.doyangopi.kasir.databinding.ActivityHppBinding
import com.doyangopi.kasir.util.HppManager
import com.doyangopi.kasir.util.PriceCalculator

class HppActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHppBinding
    private lateinit var hppManager: HppManager
    private val fields = mutableMapOf<String, EditText>()
    private val addOnFields = mutableMapOf<String, EditText>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHppBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.title = "HPP Menu"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        hppManager = HppManager(this)
        buildForm()
        buildAddOnForm()

        binding.btnSaveHpp.setOnClickListener { saveAll() }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildForm() {
        val container = binding.layoutHppList
        container.removeAllViews()

        PriceCalculator.ALL_MENUS.forEach { menu ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(6), 0, dp(6))
            }
            val label = TextView(this).apply {
                text = menu
                setTextColor(Color.WHITE)
                textSize = 12f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            val prefix = TextView(this).apply {
                text = "Rp "
                setTextColor(Color.parseColor("#AAAAAA"))
                textSize = 12f
            }
            val input = EditText(this).apply {
                setText(if (hppManager.getHpp(menu) > 0) hppManager.getHpp(menu).toString() else "")
                hint = "0"
                setHintTextColor(Color.parseColor("#666688"))
                inputType = InputType.TYPE_CLASS_NUMBER
                setTextColor(Color.WHITE)
                textSize = 13f
                gravity = Gravity.END
                layoutParams = LinearLayout.LayoutParams(dp(80), LinearLayout.LayoutParams.WRAP_CONTENT)
            }
            fields[menu] = input

            row.addView(label)
            row.addView(prefix)
            row.addView(input)
            container.addView(row)

            val divider = View(this).apply {
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1))
                setBackgroundColor(Color.parseColor("#222244"))
            }
            container.addView(divider)
        }
    }

    private fun buildAddOnForm() {
        val container = binding.layoutAddOnHppList
        container.removeAllViews()

        PriceCalculator.ADD_ONS.forEach { addOn ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(6), 0, dp(6))
            }
            val label = TextView(this).apply {
                text = "${addOn.label}  (jual +${PriceCalculator.format(addOn.price)})"
                setTextColor(Color.WHITE)
                textSize = 12f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            val prefix = TextView(this).apply {
                text = "Rp "
                setTextColor(Color.parseColor("#AAAAAA"))
                textSize = 12f
            }
            val input = EditText(this).apply {
                setText(hppManager.getAddOnHpp(addOn.label).toString())
                hint = "0"
                setHintTextColor(Color.parseColor("#666688"))
                inputType = InputType.TYPE_CLASS_NUMBER
                setTextColor(Color.WHITE)
                textSize = 13f
                gravity = Gravity.END
                layoutParams = LinearLayout.LayoutParams(dp(80), LinearLayout.LayoutParams.WRAP_CONTENT)
            }
            addOnFields[addOn.label] = input

            row.addView(label)
            row.addView(prefix)
            row.addView(input)
            container.addView(row)

            val divider = View(this).apply {
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1))
                setBackgroundColor(Color.parseColor("#222244"))
            }
            container.addView(divider)
        }
    }

    private fun saveAll() {
        val values = fields.mapValues { (_, field) ->
            field.text.toString().trim().toIntOrNull() ?: 0
        }
        hppManager.setAll(values)

        val addOnValues = addOnFields.mapValues { (_, field) ->
            field.text.toString().trim().toIntOrNull() ?: 0
        }
        hppManager.setAllAddOns(addOnValues)

        Toast.makeText(this, "✅ HPP disimpan", Toast.LENGTH_SHORT).show()
        finish()
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}
