package com.doyangopi.kasir

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.doyangopi.kasir.data.DatabaseHelper
import com.doyangopi.kasir.data.Transaction
import com.doyangopi.kasir.databinding.ActivityReportBinding
import com.doyangopi.kasir.util.ExcelExporter
import com.doyangopi.kasir.util.HppManager
import com.doyangopi.kasir.util.PriceCalculator
import com.doyangopi.kasir.util.ProfitCalculator
import kotlinx.coroutines.*
import java.text.SimpleDateFormat
import java.util.*

class ReportActivity : AppCompatActivity() {

    private lateinit var binding: ActivityReportBinding
    private lateinit var db: DatabaseHelper
    private lateinit var hppManager: HppManager
    private lateinit var adapter: TransactionAdapter
    private val scope = CoroutineScope(Dispatchers.Main + Job())
    private val transactions = mutableListOf<Transaction>()
    private var currentPeriod = "today"
    private val DAY_NAMES = arrayOf("Min","Sen","Sel","Rab","Kam","Jum","Sab")

    private val allMenus = PriceCalculator.ALL_MENUS

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityReportBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.title = "Laporan"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        db = DatabaseHelper(this)
        hppManager = HppManager(this)
        setupRecyclerView()
        setupPeriodButtons()
        loadReport("today")
        binding.btnExport.setOnClickListener { exportToExcel() }
        binding.btnAturHpp.setOnClickListener { startActivity(Intent(this, HppActivity::class.java)) }
    }

    override fun onResume() {
        super.onResume()
        // Refresh in case HPP was just edited
        loadReport(currentPeriod)
    }

    // ─── PERIOD ────────────────────────────────────────────────────────────

    private fun setupPeriodButtons() {
        binding.btnPeriodToday.setOnClickListener { loadReport("today") }
        binding.btnPeriodWeek.setOnClickListener  { loadReport("week")  }
        binding.btnPeriodMonth.setOnClickListener { loadReport("month") }
    }

    private fun setPeriodUI(period: String) {
        val gold = ContextCompat.getColorStateList(this, R.color.coffee_gold)
        val blue = ContextCompat.getColorStateList(this, R.color.medium_blue)
        listOf(binding.btnPeriodToday to "today", binding.btnPeriodWeek to "week", binding.btnPeriodMonth to "month")
            .forEach { (btn, p) ->
                btn.backgroundTintList = if (p == period) gold else blue
                btn.setTextColor(if (p == period) ContextCompat.getColor(this, R.color.dark_navy) else Color.WHITE)
            }
    }

    // ─── LOAD ──────────────────────────────────────────────────────────────

    private fun loadReport(period: String) {
        currentPeriod = period
        setPeriodUI(period)
        val txs = when (period) {
            "week"  -> db.getWeekTransactions()
            "month" -> db.getMonthTransactions()
            else    -> db.getTodayTransactions()
        }
        val totalExp = when (period) {
            "week"  -> db.getWeekExpenses()
            "month" -> db.getMonthExpenses()
            else    -> db.getTodayExpenses()
        }.sumOf { it.amount }

        transactions.clear(); transactions.addAll(txs)
        if (period == "today") adapter.notifyDataSetChanged()

        updateSummary(txs, totalExp)
        buildHourlyChart(txs)
        buildMenuRanking(txs)

        when (period) {
            "today" -> {
                binding.tvBreakdownHeader.visibility = View.GONE
                binding.cardBreakdown.visibility     = View.GONE
                binding.tvTransHeader.visibility     = View.VISIBLE
                binding.cardTransactions.visibility  = View.VISIBLE
                binding.tvEmptyList.visibility       = if (txs.isEmpty()) View.VISIBLE else View.GONE
                binding.rvTransactions.visibility    = if (txs.isEmpty()) View.GONE    else View.VISIBLE
            }
            else -> {
                val label = if (period == "week") "  📅 RINCIAN PER TANGGAL — MINGGU INI"
                            else                  "  📅 RINCIAN PER TANGGAL — BULAN INI"
                binding.tvBreakdownHeader.text       = label
                binding.tvBreakdownHeader.visibility = View.VISIBLE
                binding.cardBreakdown.visibility     = View.VISIBLE
                binding.tvTransHeader.visibility     = View.GONE
                binding.cardTransactions.visibility  = View.GONE
                buildDateBreakdown(txs)
            }
        }
    }

    // ─── SUMMARY ───────────────────────────────────────────────────────────

    private fun updateSummary(txs: List<Transaction>, totalExpense: Int) {
        val totalOmzet  = txs.sumOf { it.totalPrice }
        val totalCups   = txs.sumOf { it.qty }
        val totalOrders = txs.map { it.queueNumber }.distinct().size
        val cashOmzet   = txs.filter { it.paymentMethod == "Cash" }.sumOf { it.totalPrice }
        val qrisOmzet   = txs.filter { it.paymentMethod == "QRIS" }.sumOf { it.totalPrice }
        val extraShotCt = txs.filter { it.extraShot }.sumOf { it.qty }
        val net         = totalOmzet - totalExpense

        binding.tvOmzet.text    = "Omzet: ${PriceCalculator.format(totalOmzet)}"
        binding.tvTotalCup.text = "☕ $totalCups cup"
        binding.tvOrders.text   = "🧾 $totalOrders pesanan"
        binding.tvRobusta.text  = "💵 Cash: ${PriceCalculator.format(cashOmzet)}"
        binding.tvArabica.text  = "📱 QRIS: ${PriceCalculator.format(qrisOmzet)}"

        val extras = mutableListOf<String>()
        if (totalExpense > 0) {
            extras.add("💸 Pengeluaran: ${PriceCalculator.format(totalExpense)}")
            extras.add("📈 Net: ${PriceCalculator.format(net)}${if (net < 0) " ⚠️" else ""}")
        }
        if (extraShotCt > 0)
            extras.add("★ Extra Shot: $extraShotCt kali (${(extraShotCt * 100f / totalCups.coerceAtLeast(1)).toInt()}%)")
        binding.tvExtraShot.text = extras.joinToString("\n")

        updateProfitCard(txs)
    }

    // ─── HPP & MARGIN ──────────────────────────────────────────────────────

    private fun updateProfitCard(txs: List<Transaction>) {
        val hppMap      = hppManager.getAll(allMenus)
        val addOnHppMap = hppManager.getAllAddOns(PriceCalculator.ADD_ONS.map { it.label })
        val summary     = ProfitCalculator.calculate(txs, hppMap, addOnHppMap)

        binding.tvHppOmzet.text     = "Omzet: ${PriceCalculator.format(summary.revenue)}"
        binding.tvHppModal.text     = "Modal (HPP): ${PriceCalculator.format(summary.hppCost)}"
        binding.tvHppOverhead.text  = "Overhead (30%): ${PriceCalculator.format(summary.overheadCost)}"
        binding.tvHppMarginPct.text = "Margin: ${String.format("%.1f", summary.marginPercent)}%"
        binding.tvHppNetProfit.text =
            "Profit Bersih: ${PriceCalculator.format(summary.netProfit)}${if (summary.netProfit < 0) " ⚠️" else ""}"

        if (summary.unconfiguredCount > 0 && txs.isNotEmpty()) {
            binding.tvHppWarning.visibility = View.VISIBLE
            binding.tvHppWarning.text =
                "⚠️ ${summary.unconfiguredCount} item belum ada HPP-nya (dihitung modal Rp 0). Tap \"Atur HPP\" untuk mengisi."
        } else {
            binding.tvHppWarning.visibility = View.GONE
        }
    }

    // ─── GRAFIK JAM ────────────────────────────────────────────────────────

    private fun buildHourlyChart(txs: List<Transaction>) {
        val container = binding.layoutHourlyChart
        container.removeAllViews()
        if (txs.isEmpty()) { addEmptyLabel(container, "Belum ada data"); return }
        val sdfH = SimpleDateFormat("H", Locale.getDefault())
        val hourly = txs.groupBy { sdfH.format(Date(it.timestamp)).toInt() }
            .mapValues { e -> e.value.sumOf { it.qty } }.toSortedMap()
        val maxQty  = hourly.values.maxOrNull() ?: 1
        val maxBarW = (resources.displayMetrics.widthPixels * 0.50f).toInt()
        hourly.forEach { (hour, qty) ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                layoutParams = llParams(matchParent = true, h = dp(26), bMargin = dp(2))
            }
            row.addView(tv("${String.format("%02d", hour)}:00", "#AAAAAA", 11f,
                LinearLayout.LayoutParams(dp(52), lp_wrap)))
            val bw = ((qty.toFloat() / maxQty) * maxBarW).toInt().coerceAtLeast(dp(4))
            row.addView(View(this).apply {
                setBackgroundColor(Color.parseColor("#F5CBA7"))
                layoutParams = LinearLayout.LayoutParams(bw, dp(12)).apply { marginEnd = dp(8) }
            })
            row.addView(tv("$qty cup", "#FFFFFF", 11f))
            if (qty == maxQty) row.addView(tv("  🔥", "#FF9944", 12f))
            container.addView(row)
        }
    }

    // ─── RANKING MENU ──────────────────────────────────────────────────────

    private fun buildMenuRanking(txs: List<Transaction>) {
        val container = binding.layoutMenuRanking
        container.removeAllViews()
        if (txs.isEmpty()) { addEmptyLabel(container, "Belum ada data"); return }
        val ranked  = txs.groupBy { it.menu }
            .mapValues { e -> e.value.sumOf { it.qty } }
            .entries.sortedByDescending { it.value }
        val maxQty  = ranked.firstOrNull()?.value ?: 1
        val maxBarW = (resources.displayMetrics.widthPixels * 0.42f).toInt()
        val medals  = listOf("🥇","🥈","🥉")
        val cols    = listOf("#F5CBA7","#C0C0C0","#CD7F32")
        ranked.forEachIndexed { i, (menu, qty) ->
            val col   = if (i < cols.size) Color.parseColor(cols[i]) else Color.parseColor("#556688")
            val omzet = txs.filter { it.menu == menu }.sumOf { it.totalPrice }
            container.addView(tv("${if (i < medals.size) medals[i] else "${i+1}."} $menu",
                if (i == 0) "#F5CBA7" else "#FFFFFF", 12f,
                llParams(matchParent = true, bMargin = dp(3)),
                bold = i == 0))
            val barRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                layoutParams = llParams(matchParent = true, bMargin = dp(10))
            }
            val bw = ((qty.toFloat() / maxQty) * maxBarW).toInt().coerceAtLeast(dp(6))
            barRow.addView(View(this).apply {
                setBackgroundColor(col)
                layoutParams = LinearLayout.LayoutParams(bw, dp(10)).apply { marginEnd = dp(8) }
            })
            barRow.addView(tv("$qty cup  ·  ${PriceCalculator.format(omzet)}", "#AAAAAA", 11f))
            container.addView(barRow)
        }
    }

    // ─── RINCIAN PER TANGGAL ───────────────────────────────────────────────

    private fun buildDateBreakdown(txs: List<Transaction>) {
        val container = binding.layoutBreakdown
        container.removeAllViews()
        if (txs.isEmpty()) { addEmptyLabel(container, "Belum ada transaksi periode ini"); return }
        val sdfDate = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        val sdfTime = SimpleDateFormat("HH:mm", Locale.getDefault())
        val dailyMap = txs.groupBy {
            val c = Calendar.getInstance().apply { timeInMillis = it.timestamp }
            c.get(Calendar.YEAR) * 1000 + c.get(Calendar.DAY_OF_YEAR)
        }.toSortedMap()

        dailyMap.forEach { (_, dayTxs) ->
            val cal      = Calendar.getInstance().apply { timeInMillis = dayTxs.first().timestamp }
            val dayName  = DAY_NAMES[cal.get(Calendar.DAY_OF_WEEK) - 1]
            val dayOmzet = dayTxs.sumOf { it.totalPrice }
            val dayCups  = dayTxs.sumOf { it.qty }
            val dayOrds  = dayTxs.map { it.queueNumber }.distinct().size

            // Date header
            container.addView(LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                layoutParams = llParams(matchParent = true, bMargin = dp(4))
                setPadding(0, dp(8), 0, dp(4))
                addView(tv("📅 $dayName, ${sdfDate.format(cal.time)}", "#F5CBA7", 12f,
                    LinearLayout.LayoutParams(0, lp_wrap, 1f), bold = true))
                addView(tv("${PriceCalculator.format(dayOmzet)} ($dayCups cup · $dayOrds)",
                    "#F5CBA7", 11f, null, gravity = Gravity.END))
            })

            // Group by queue
            dayTxs.groupBy { it.queueNumber }.forEach { (queue, qTxs) ->
                val qTotal   = qTxs.sumOf { it.totalPrice }
                val timeStr  = sdfTime.format(Date(qTxs.first().timestamp))
                val payment  = qTxs.first().paymentMethod
                container.addView(LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    layoutParams = llParams(matchParent = true, bMargin = dp(2))
                    setPadding(dp(8), dp(2), 0, 0)
                    addView(tv("$timeStr  $queue", "#888888", 10f,
                        LinearLayout.LayoutParams(dp(110), lp_wrap)))
                    addView(tv("[$payment]",
                        if (payment == "QRIS") "#7799FF" else "#77CC88", 9f,
                        LinearLayout.LayoutParams(0, lp_wrap, 1f)))
                    addView(tv(PriceCalculator.format(qTotal), "#FFFFFF", 11f,
                        LinearLayout.LayoutParams(dp(90), lp_wrap), bold = true, gravity = Gravity.END))
                })
                qTxs.forEach { t ->
                    val shot   = if (t.extraShot) " +Shot" else ""
                    val qtyStr = if (t.qty > 1) " ×${t.qty}" else ""
                    container.addView(LinearLayout(this).apply {
                        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                        layoutParams = llParams(matchParent = true, bMargin = dp(1))
                        setPadding(dp(20), 0, 0, 0)
                        addView(View(this@ReportActivity).apply {
                            setBackgroundColor(Color.parseColor("#444466"))
                            layoutParams = LinearLayout.LayoutParams(dp(2), dp(16)).apply { marginEnd = dp(6) }
                        })
                        addView(tv("${t.menu}$shot$qtyStr", "#CCCCCC", 11f,
                            LinearLayout.LayoutParams(0, lp_wrap, 1f),
                            maxLines = 1))
                        addView(tv(PriceCalculator.format(t.totalPrice), "#AAAAAA", 10f,
                            LinearLayout.LayoutParams(dp(80), lp_wrap), gravity = Gravity.END))
                    })
                }
            }
            container.addView(divider())
        }
    }

    // ─── RECYCLERVIEW (Hari Ini) + EDIT/DELETE ────────────────────────────

    private fun setupRecyclerView() {
        adapter = TransactionAdapter(
            transactions,
            onEdit   = { t, pos -> showEditDialog(t, pos) },
            onDelete = { t, pos ->
                AlertDialog.Builder(this)
                    .setTitle("Hapus item ini?")
                    .setMessage("${t.queueNumber} — ${t.menu}\n${PriceCalculator.format(t.totalPrice)}")
                    .setPositiveButton("Hapus") { _, _ ->
                        if (db.deleteTransaction(t.id)) {
                            transactions.removeAt(pos); adapter.notifyItemRemoved(pos)
                            updateSummary(transactions, db.getTodayExpenses().sumOf { it.amount })
                            buildHourlyChart(transactions); buildMenuRanking(transactions)
                            Toast.makeText(this, "✅ Item dihapus", Toast.LENGTH_SHORT).show()
                        }
                    }
                    .setNegativeButton("Batal", null).show()
            }
        )
        binding.rvTransactions.layoutManager = LinearLayoutManager(this)
        binding.rvTransactions.adapter = adapter
        binding.rvTransactions.isNestedScrollingEnabled = false
    }

    // ─── EDIT DIALOG ───────────────────────────────────────────────────────

    private fun showEditDialog(t: Transaction, position: Int) {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(8))
        }

        fun lbl(text: String) = TextView(this).apply {
            this.text = text; textSize = 12f
            setTextColor(Color.parseColor("#AAAAAA"))
            setPadding(0, dp(10), 0, dp(4))
        }

        // ── Menu ──
        layout.addView(lbl("Menu"))
        val spinnerMenu = Spinner(this)
        val menuAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, allMenus)
        menuAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerMenu.adapter = menuAdapter
        spinnerMenu.setSelection(allMenus.indexOf(t.menu).coerceAtLeast(0))
        layout.addView(spinnerMenu)

        // ── Kemanisan ──
        layout.addView(lbl("Level Gula"))
        var selectedGula = t.kemanisan
        val gulaOptions  = listOf("Normal","Less","No Sugar","Custom")
        val rgGula = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        gulaOptions.forEach { opt ->
            rgGula.addView(RadioButton(this).apply {
                text = opt; textSize = 11f; setTextColor(Color.WHITE)
                id = View.generateViewId(); isChecked = opt == selectedGula
                buttonTintList = ContextCompat.getColorStateList(this@ReportActivity, R.color.coffee_gold)
                setOnCheckedChangeListener { _, c -> if (c) selectedGula = opt }
            })
        }
        layout.addView(rgGula)

        // ── Level Es (hide for Hot variants) ──
        val cardEs = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        cardEs.addView(lbl("Level Es"))
        var selectedEs = t.levelEs
        val esOptions  = listOf("Normal","Less","No Ice")
        val rgEs = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        esOptions.forEach { opt ->
            rgEs.addView(RadioButton(this).apply {
                text = opt; textSize = 11f; setTextColor(Color.WHITE)
                id = View.generateViewId(); isChecked = opt == selectedEs
                buttonTintList = ContextCompat.getColorStateList(this@ReportActivity, R.color.coffee_gold)
                setOnCheckedChangeListener { _, c -> if (c) selectedEs = opt }
            })
        }
        cardEs.addView(rgEs)
        layout.addView(cardEs)

        // ── Extra Shot ──
        val cardShot = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, 0)
        }
        val cbShot = CheckBox(this).apply {
            text = "Extra Shot (+Rp 4.000)"; setTextColor(Color.WHITE)
            isChecked = t.extraShot
            buttonTintList = ContextCompat.getColorStateList(this@ReportActivity, R.color.coffee_gold)
        }
        cardShot.addView(cbShot)
        layout.addView(cardShot)

        // ── Add-On ──
        layout.addView(lbl("Add-On"))
        val addOnChecks = mutableMapOf<String, CheckBox>()
        PriceCalculator.ADD_ONS.forEach { addOn ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            }
            val cb = CheckBox(this).apply {
                text = "${addOn.label} (+${PriceCalculator.format(addOn.price)})"
                setTextColor(Color.WHITE)
                isChecked = t.addOns.contains(addOn.label)
                buttonTintList = ContextCompat.getColorStateList(this@ReportActivity, R.color.coffee_gold)
            }
            addOnChecks[addOn.label] = cb
            row.addView(cb)
            layout.addView(row)
        }

        // ── Qty ──
        layout.addView(lbl("Jumlah"))
        var qty = t.qty
        val qtyRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        }
        val tvQty = TextView(this).apply {
            text = qty.toString(); setTextColor(Color.WHITE)
            textSize = 18f; gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(dp(48), lp_wrap)
        }
        qtyRow.addView(Button(this).apply {
            text = "-"; setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(dp(40), dp(40))
            backgroundTintList = ContextCompat.getColorStateList(this@ReportActivity, R.color.medium_blue)
            setOnClickListener { if (qty > 1) { qty--; tvQty.text = qty.toString() } }
        })
        qtyRow.addView(tvQty)
        qtyRow.addView(Button(this).apply {
            text = "+"; setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(dp(40), dp(40))
            backgroundTintList = ContextCompat.getColorStateList(this@ReportActivity, R.color.medium_blue)
            setOnClickListener { qty++; tvQty.text = qty.toString() }
        })
        layout.addView(qtyRow)

        // ── Notes ──
        layout.addView(lbl("Catatan"))
        val etNotes = EditText(this).apply {
            setText(t.notes)
            inputType = InputType.TYPE_CLASS_TEXT
            setTextColor(Color.WHITE)
        }
        layout.addView(etNotes)

        // Update visibility based on menu selection
        fun refreshVisibility() {
            val m = allMenus[spinnerMenu.selectedItemPosition]
            cardEs.visibility   = if (PriceCalculator.isHot(m)) View.GONE else View.VISIBLE
            cardShot.visibility = if (PriceCalculator.allowsExtraShot(m)) View.VISIBLE else View.GONE
            if (!PriceCalculator.allowsExtraShot(m)) cbShot.isChecked = false
        }
        refreshVisibility()
        spinnerMenu.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(p: android.widget.AdapterView<*>?, v: View?, pos: Int, id: Long) {
                refreshVisibility()
            }
        }

        AlertDialog.Builder(this)
            .setTitle("✏️ Edit ${t.queueNumber}")
            .setView(layout)
            .setPositiveButton("Simpan") { _, _ ->
                val menu      = allMenus[spinnerMenu.selectedItemPosition]
                val extraShot = cbShot.isChecked && PriceCalculator.allowsExtraShot(menu)
                val levelEs   = if (PriceCalculator.isHot(menu)) "-" else selectedEs
                val notes     = etNotes.text.toString().trim()
                val addOns    = addOnChecks.filter { it.value.isChecked }.keys.toList()
                val perItem   = PriceCalculator.pricePerItem(menu, extraShot, addOns)
                val updated   = t.copy(
                    menu = menu, kemanisan = selectedGula, levelEs = levelEs,
                    extraShot = extraShot, qty = qty, notes = notes,
                    pricePerItem = perItem, totalPrice = perItem * qty,
                    addOns = addOns
                )
                if (db.updateTransaction(updated)) {
                    transactions[position] = updated
                    adapter.updateAt(position, updated)
                    updateSummary(transactions, db.getTodayExpenses().sumOf { it.amount })
                    buildHourlyChart(transactions); buildMenuRanking(transactions)
                    Toast.makeText(this, "✅ Pesanan diupdate", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ─── EXPORT ────────────────────────────────────────────────────────────

    private fun exportToExcel() {
        binding.btnExport.isEnabled = false
        scope.launch {
            val label = when (currentPeriod) {
                "week"  -> "minggu_${SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())}"
                "month" -> "bulan_${SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(Date())}"
                else    -> SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            }
            val file = withContext(Dispatchers.IO) { ExcelExporter.export(this@ReportActivity, transactions, label) }
            binding.btnExport.isEnabled = true
            if (file != null && file.exists()) {
                val uri = FileProvider.getUriForFile(this@ReportActivity, "${packageName}.provider", file)
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                    type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }, "Bagikan Laporan"))
            } else Toast.makeText(this@ReportActivity, "Gagal membuat Excel", Toast.LENGTH_SHORT).show()
        }
    }

    // ─── HELPERS ───────────────────────────────────────────────────────────

    private fun dp(n: Int) = (n * resources.displayMetrics.density + 0.5f).toInt()
    private val lp_wrap     = LinearLayout.LayoutParams.WRAP_CONTENT
    private val matchParent = LinearLayout.LayoutParams.MATCH_PARENT

    private fun llParams(matchParent: Boolean = false, h: Int = lp_wrap, bMargin: Int = 0) =
        LinearLayout.LayoutParams(if (matchParent) this.matchParent else lp_wrap, h)
            .apply { bottomMargin = bMargin }

    private fun tv(
        text: String, color: String, size: Float,
        lp: LinearLayout.LayoutParams? = null,
        bold: Boolean = false, maxLines: Int = 0, gravity: Int = Gravity.START
    ) = TextView(this).apply {
        this.text = text; setTextColor(Color.parseColor(color)); textSize = size
        this.gravity = gravity
        if (bold) setTypeface(null, Typeface.BOLD)
        if (maxLines > 0) { this.maxLines = maxLines; ellipsize = android.text.TextUtils.TruncateAt.END }
        if (lp != null) layoutParams = lp
    }

    private fun addEmptyLabel(container: LinearLayout, msg: String) {
        container.addView(tv(msg, "#888888", 12f, llParams(matchParent = true), gravity = Gravity.CENTER))
    }

    private fun divider() = View(this).apply {
        setBackgroundColor(Color.parseColor("#2A2A4A"))
        layoutParams = LinearLayout.LayoutParams(matchParent, 1).apply { topMargin = dp(8); bottomMargin = dp(8) }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
    override fun onDestroy() { super.onDestroy(); scope.cancel() }
}
