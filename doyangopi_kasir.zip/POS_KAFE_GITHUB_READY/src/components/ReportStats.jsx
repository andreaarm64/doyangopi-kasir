
export default function ReportStats({orders=[]}){
 const omzet = orders.reduce((a,b)=>a+b.total,0);
 const daily = orders.length;

 const items={};
 orders.forEach(o=>o.items?.forEach(i=>{
   items[i.name]=(items[i.name]||0)+1;
 }));
 const top=Object.entries(items).sort((a,b)=>b[1]-a[1])[0];

 return (
 <div>
   <h2>Dashboard</h2>
   <div>Transaksi: {daily}</div>
   <div>Omzet: Rp{omzet}</div>
   <div>Terlaris: {top ? top[0] : '-'}</div>
 </div>)
}
