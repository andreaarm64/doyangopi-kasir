
import {saveOrder} from './db';
import {generateOrderNumber} from './orderNumber';

export async function processCheckout(cart,total){
 const order={
   id:crypto.randomUUID(),
   orderId:generateOrderNumber(1),
   date:new Date().toISOString(),
   items:cart,
   total
 };
 await saveOrder(order);
 return order;
}
