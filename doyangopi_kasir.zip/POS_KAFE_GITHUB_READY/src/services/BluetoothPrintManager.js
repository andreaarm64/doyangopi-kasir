
import { buildEscPosReceipt } from './escposService';

export async function connect58mmPrinter(){
 const device = await navigator.bluetooth.requestDevice({
   acceptAllDevices:true,
   optionalServices:[0xFFE0]
 });
 const server = await device.gatt.connect();
 return {device, server};
}

export async function sendReceipt(characteristic, order){
 const bytes = buildEscPosReceipt(order);
 await characteristic.writeValue(bytes);
}
