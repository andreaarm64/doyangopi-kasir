package com.doyangopi.kasir

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.doyangopi.kasir.util.PriceCalculator
import com.doyangopi.kasir.util.ProfitCalculator

data class HistoryRow(
    val label: String,
    val cupCount: Int,
    val summary: ProfitCalculator.ProfitSummary,
    val expenseTotal: Int = 0,
    val expenseBreakdown: String = ""
)

class HistoryAdapter(private val items: MutableList<HistoryRow> = mutableListOf()) :
    RecyclerView.Adapter<HistoryAdapter.VH>() {

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tvLabel     : TextView = v.findViewById(R.id.tvLabel)
        val tvCups      : TextView = v.findViewById(R.id.tvCups)
        val tvOmzet     : TextView = v.findViewById(R.id.tvOmzet)
        val tvModal     : TextView = v.findViewById(R.id.tvModal)
        val tvOverhead  : TextView = v.findViewById(R.id.tvOverhead)
        val tvMarginPct : TextView = v.findViewById(R.id.tvMarginPct)
        val tvNetProfit : TextView = v.findViewById(R.id.tvNetProfit)
        val layoutExpense       : View     = v.findViewById(R.id.layoutExpense)
        val tvExpenseTotal      : TextView = v.findViewById(R.id.tvExpenseTotal)
        val tvExpenseBreakdown  : TextView = v.findViewById(R.id.tvExpenseBreakdown)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_history_summary, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val row = items[position]
        val s   = row.summary

        holder.tvLabel.text     = row.label
        holder.tvCups.text      = "☕ ${row.cupCount} cup"
        holder.tvOmzet.text     = "Omzet: ${PriceCalculator.format(s.revenue)}"
        holder.tvModal.text     = "Modal (HPP): ${PriceCalculator.format(s.hppCost)}"
        holder.tvOverhead.text  = "Overhead (30%): ${PriceCalculator.format(s.overheadCost)}"
        holder.tvMarginPct.text = "Margin: ${String.format("%.1f", s.marginPercent)}%"
        holder.tvNetProfit.text =
            "Profit Bersih: ${PriceCalculator.format(s.netProfit)}${if (s.netProfit < 0) " ⚠️" else ""}"

        if (row.expenseBreakdown.isNotBlank()) {
            holder.layoutExpense.visibility = View.VISIBLE
            holder.tvExpenseTotal.text = "💸 Pengeluaran: ${PriceCalculator.format(row.expenseTotal)}"
            holder.tvExpenseBreakdown.text = row.expenseBreakdown
        } else {
            holder.layoutExpense.visibility = View.GONE
        }
    }

    override fun getItemCount() = items.size

    fun replaceAll(newItems: List<HistoryRow>) {
        items.clear(); items.addAll(newItems); notifyDataSetChanged()
    }
}
