package com.doyangopi.kasir

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.doyangopi.kasir.data.CartItem
import com.doyangopi.kasir.util.PriceCalculator

class CartAdapter(
    private val items: MutableList<CartItem>,
    private val onDelete: (Int) -> Unit
) : RecyclerView.Adapter<CartAdapter.VH>() {

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tvMenu   : TextView = v.findViewById(R.id.tvCartMenu)
        val tvDetail : TextView = v.findViewById(R.id.tvCartDetail)
        val tvPrice  : TextView = v.findViewById(R.id.tvCartPrice)
        val btnDelete: TextView = v.findViewById(R.id.btnCartDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_cart, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        val shot = if (item.extraShot) " + Extra Shot" else ""
        holder.tvMenu.text = "${position + 1}. ${item.menu}$shot  ×${item.qty}"

        val parts = mutableListOf(item.kemanisan)
        if (item.levelEs != "-") parts.add("Es: ${item.levelEs}")
        if (item.notes.isNotBlank()) parts.add(item.notes)
        holder.tvDetail.text = parts.joinToString(" · ")

        holder.tvPrice.text = PriceCalculator.format(item.totalPrice)

        holder.btnDelete.setOnClickListener {
            val pos = holder.adapterPosition
            if (pos != RecyclerView.NO_ID.toInt()) onDelete(pos)
        }
    }

    override fun getItemCount() = items.size

    fun removeAt(pos: Int) {
        items.removeAt(pos)
        notifyItemRemoved(pos)
    }

    fun addItem(item: CartItem) {
        items.add(item)
        notifyItemInserted(items.size - 1)
    }
}
