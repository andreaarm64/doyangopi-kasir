package com.doyangopi.kasir.util

import com.doyangopi.kasir.data.Transaction
import kotlin.math.roundToInt

/**
 * Menghitung margin/keuntungan bersih berdasarkan HPP per menu + asumsi overhead.
 * Overhead dihitung sebagai persentase dari omzet (harga jual, termasuk add-on),
 * jadi margin yang dihasilkan sudah otomatis memperhitungkan add-on.
 */
object ProfitCalculator {

    const val OVERHEAD_PERCENT = 0.30  // 30% dari omzet

    data class ProfitSummary(
        val revenue: Int,        // omzet (sudah termasuk add-on)
        val hppCost: Int,        // total modal: HPP menu + HPP add-on
        val overheadCost: Int,   // 30% dari omzet
        val netProfit: Int,      // revenue - hppCost - overheadCost
        val marginPercent: Double,
        val unconfiguredCount: Int  // jumlah transaksi dengan menu yg HPP-nya belum diisi
    )

    fun calculate(
        transactions: List<Transaction>,
        hppMap: Map<String, Int>,
        addOnHppMap: Map<String, Int> = emptyMap()
    ): ProfitSummary {
        var revenue = 0
        var hppCost = 0
        var unconfigured = 0

        transactions.forEach { t ->
            revenue += t.totalPrice
            val hppPerUnit = hppMap[t.menu] ?: 0
            if (hppPerUnit == 0) unconfigured++
            val addOnHppPerUnit = t.addOns.sumOf { addOnHppMap[it] ?: 0 }
            hppCost += (hppPerUnit + addOnHppPerUnit) * t.qty
        }

        val overhead = (revenue * OVERHEAD_PERCENT).roundToInt()
        val net = revenue - hppCost - overhead
        val marginPct = if (revenue > 0) (net.toDouble() / revenue) * 100 else 0.0

        return ProfitSummary(
            revenue = revenue,
            hppCost = hppCost,
            overheadCost = overhead,
            netProfit = net,
            marginPercent = marginPct,
            unconfiguredCount = unconfigured
        )
    }
}
