package com.doyangopi.kasir.util

import android.content.Context
import com.doyangopi.kasir.data.DatabaseHelper
import com.doyangopi.kasir.data.MenuItem

/**
 * Cache menu di memori, di-load dari tabel menu_items.
 * Panggil load() di onCreate/onResume setiap layar yang butuh daftar menu terbaru
 * (misalnya setelah menu ditambah/diedit di layar Kelola Menu).
 */
object MenuCache {

    private var items: List<MenuItem> = emptyList()
    private var byName: Map<String, MenuItem> = emptyMap()

    fun load(context: Context) {
        val db = DatabaseHelper(context.applicationContext)
        items = db.getAllMenus()
        byName = items.associateBy { it.name }
    }

    fun all(): List<MenuItem> = items
    fun names(): List<String> = items.map { it.name }
    fun get(name: String): MenuItem? = byName[name]
}
