package com.doyangopi.kasir.bluetooth

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import com.doyangopi.kasir.R
import com.doyangopi.kasir.data.Transaction
import java.io.IOException
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.*

class BluetoothPrinter(private val context: Context) {

    companion object {
        private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        private const val PREF     = "bt_printer"
        private const val KEY_ADDR = "address"
        private const val KEY_NAME = "name"

        // ESC/POS commands
        private val INIT       = byteArrayOf(0x1B, 0x40)
        private val ALIGN_CTR  = byteArrayOf(0x1B, 0x61, 0x01)
        private val ALIGN_LEFT = byteArrayOf(0x1B, 0x61, 0x00)
        private val BOLD_ON    = byteArrayOf(0x1B, 0x45, 0x01)
        private val BOLD_OFF   = byteArrayOf(0x1B, 0x45, 0x00)
        private val CUT        = byteArrayOf(0x1D, 0x56, 0x41, 0x10)

        private val DAYS_ID = arrayOf("Minggu","Senin","Selasa","Rabu","Kamis","Jumat","Sabtu")
    }

    private val prefs: SharedPreferences = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
    private var socket: BluetoothSocket? = null
    private var out: OutputStream? = null

    fun savedAddress(): String? = prefs.getString(KEY_ADDR, null)
    fun savedName():    String? = prefs.getString(KEY_NAME, null)

    fun save(address: String, name: String) {
        prefs.edit().putString(KEY_ADDR, address).putString(KEY_NAME, name).apply()
    }

    @SuppressLint("MissingPermission")
    fun connect(device: BluetoothDevice): Boolean {
        return try {
            disconnect()
            socket = device.createRfcommSocketToServiceRecord(SPP_UUID)
            socket!!.connect()
            out = socket!!.outputStream
            true
        } catch (e: IOException) { disconnect(); false }
    }

    fun disconnect() {
        try { out?.close(); socket?.close() } catch (e: IOException) { }
        out = null; socket = null
    }

    fun isConnected() = socket?.isConnected == true

    private fun b(bytes: ByteArray) { out?.write(bytes) }
    private fun line(text: String = "") {
        out?.write((text + "\n").toByteArray(Charsets.ISO_8859_1))
    }
    private fun sep() = line("--------------------------------")

    // ─── Cetak logo ke printer ESC/POS ───────────────────────────────────────
    private fun printLogo() {
        try {
            val raw = BitmapFactory.decodeResource(context.resources, R.drawable.logo_doyangopi)
                ?: return
            val targetWidth = 256
            val scale  = targetWidth.toFloat() / raw.width
            val scaled = Bitmap.createScaledBitmap(raw, targetWidth, (raw.height * scale).toInt(), true)
            raw.recycle()

            val w = scaled.width
            val h = scaled.height
            val bytesPerRow = (w + 7) / 8
            val data   = ByteArray(bytesPerRow * h)
            val pixels = IntArray(w * h)
            scaled.getPixels(pixels, 0, w, 0, 0, w, h)
            scaled.recycle()

            for (y in 0 until h) {
                for (x in 0 until w) {
                    val px     = pixels[y * w + x]
                    val alpha  = Color.alpha(px)
                    val bright = if (alpha < 128) 255
                                 else (Color.red(px) * 0.299 + Color.green(px) * 0.587 + Color.blue(px) * 0.114).toInt()
                    if (bright < 128) {
                        data[y * bytesPerRow + x / 8] =
                            (data[y * bytesPerRow + x / 8].toInt() or (0x80 shr (x % 8))).toByte()
                    }
                }
            }

            // GS v 0 — raster bit image
            val header = byteArrayOf(
                0x1D, 0x76, 0x30, 0x00,
                (bytesPerRow and 0xFF).toByte(), ((bytesPerRow shr 8) and 0xFF).toByte(),
                (h and 0xFF).toByte(), ((h shr 8) and 0xFF).toByte()
            )
            out?.write(header)
            out?.write(data)
        } catch (e: Exception) {
            // Jika logo gagal cetak, lanjut tanpa logo
        }
    }

    // ─── Struk CUSTOMER (cetak lebih dulu) ────────────────────────────────────
    fun printCustomer(t: Transaction): Boolean {
        return try {
            val cal     = Calendar.getInstance().apply { timeInMillis = t.timestamp }
            val dayName = DAYS_ID[cal.get(Calendar.DAY_OF_WEEK) - 1]
            val dateFmt = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(t.timestamp))
            val timeFmt = SimpleDateFormat("HH:mm",      Locale.getDefault()).format(Date(t.timestamp))
            val total   = "Rp" + String.format("%,d", t.totalPrice).replace(',', '.')

            b(INIT)
            b(ALIGN_CTR)

            // Logo
            printLogo()
            line()

            // Sosmed
            line("ig @doyangopi4  |  tiktok @doyangopi_")
            sep()

            // Nama toko
            b(BOLD_ON)
            line("=== DOYANGOPI ===")
            b(BOLD_OFF)
            line()

            // Info order
            b(ALIGN_LEFT)
            line("No      : ${t.queueNumber}")
            line("Hari    : $dayName, $dateFmt")
            line("Jam     : $timeFmt")
            line()

            // Menu
            b(BOLD_ON)
            line("${t.menu}${if (t.levelKopi != "-") " (${t.levelKopi})" else ""}")
            b(BOLD_OFF)
            if (t.beans != "-")         line(t.beans)
            if (t.qty > 1)              line("${t.qty}x")
            if (t.notes.isNotBlank())   line("Catatan: ${t.notes}")

            // Total
            line()
            sep()
            line("Total   : $total")
            sep()
            line()
            b(ALIGN_CTR)
            line("Terima kasih! ☕")
            line(); line(); line()
            b(CUT)
            out?.flush()
            true
        } catch (e: IOException) { false }
    }

    // ─── Struk KITCHEN (cetak setelah 5 detik) ────────────────────────────────
    fun printKitchen(t: Transaction): Boolean {
        return try {
            val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(t.timestamp))

            b(INIT)
            b(ALIGN_CTR)
            b(BOLD_ON)
            line("=== DOYANGOPI ===")
            b(BOLD_OFF)
            line()
            b(ALIGN_LEFT)
            line("No      : ${t.queueNumber}")
            line()
            line("Menu    : ${t.menu}")
            if (t.beans != "-")       line("Beans   : ${t.beans}")
            if (t.levelKopi != "-")   line("Kopi    : ${t.levelKopi}")
            line("Gula    : ${t.kemanisan}")
            if (t.levelEs != "-")     line("Es      : ${t.levelEs}")
            if (t.qty > 1)            line("Qty     : ${t.qty}x")
            if (t.notes.isNotBlank()) line("Catatan : ${t.notes}")
            line()
            line("Jam     : $timeFmt")
            line(); line(); line()
            b(CUT)
            out?.flush()
            true
        } catch (e: IOException) { false }
    }
}
