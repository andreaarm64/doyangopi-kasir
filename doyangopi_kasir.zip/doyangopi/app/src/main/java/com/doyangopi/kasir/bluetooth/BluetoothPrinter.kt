package com.doyangopi.kasir.bluetooth

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import com.doyangopi.kasir.R
import com.doyangopi.kasir.data.CartItem
import java.io.IOException
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.*

class BluetoothPrinter(private val context: Context) {

    companion object {
        private val SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        private const val PREF     = "bt_printer"
        private const val KEY_ADDR = "address"
        private const val KEY_NAME = "name"

        private val INIT       = byteArrayOf(0x1B, 0x40)
        private val ALIGN_CTR  = byteArrayOf(0x1B, 0x61, 0x01)
        private val ALIGN_LEFT = byteArrayOf(0x1B, 0x61, 0x00)
        private val BOLD_ON    = byteArrayOf(0x1B, 0x45, 0x01)
        private val BOLD_OFF   = byteArrayOf(0x1B, 0x45, 0x00)
        private val CUT        = byteArrayOf(0x1D, 0x56, 0x41, 0x10)

        private val DAYS_ID = arrayOf("Minggu","Senin","Selasa","Rabu","Kamis","Jumat","Sabtu")
    }

    private val prefs: SharedPreferences = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
    private var socket: BluetoothSocket? = null
    private var out: OutputStream? = null

    fun savedAddress(): String? = prefs.getString(KEY_ADDR, null)
    fun savedName():    String? = prefs.getString(KEY_NAME, null)
    fun save(address: String, name: String) =
        prefs.edit().putString(KEY_ADDR, address).putString(KEY_NAME, name).apply()

    @SuppressLint("MissingPermission")
    fun connect(device: BluetoothDevice): Boolean = try {
        disconnect()
        socket = device.createRfcommSocketToServiceRecord(SPP_UUID)
        socket!!.connect()
        out = socket!!.outputStream
        true
    } catch (e: IOException) { disconnect(); false }

    fun disconnect() {
        try { out?.close(); socket?.close() } catch (_: IOException) {}
        out = null; socket = null
    }

    fun isConnected() = socket?.isConnected == true

    private fun b(bytes: ByteArray) { out?.write(bytes) }
    private fun line(text: String = "") {
        out?.write((text + "\n").toByteArray(Charsets.ISO_8859_1))
    }
    private fun sep() = line("================================")

    private fun printBitmap(resId: Int, targetWidth: Int = 376) {
        try {
            val raw    = BitmapFactory.decodeResource(context.resources, resId) ?: return
            val scale  = targetWidth.toFloat() / raw.width
            val scaled = Bitmap.createScaledBitmap(raw, targetWidth, (raw.height * scale).toInt(), true)
            raw.recycle()

            val w = scaled.width; val h = scaled.height
            val bpr = (w + 7) / 8
            val data = ByteArray(bpr * h)
            val pixels = IntArray(w * h)
            scaled.getPixels(pixels, 0, w, 0, 0, w, h)
            scaled.recycle()

            for (y in 0 until h) for (x in 0 until w) {
                val px     = pixels[y * w + x]
                val alpha  = Color.alpha(px)
                val bright = if (alpha < 128) 255
                             else (Color.red(px) * 0.299 + Color.green(px) * 0.587 + Color.blue(px) * 0.114).toInt()
                if (bright < 128)
                    data[y * bpr + x / 8] = (data[y * bpr + x / 8].toInt() or (0x80 shr (x % 8))).toByte()
            }

            out?.write(byteArrayOf(
                0x1D, 0x76, 0x30, 0x00,
                (bpr and 0xFF).toByte(), ((bpr shr 8) and 0xFF).toByte(),
                (h and 0xFF).toByte(), ((h shr 8) and 0xFF).toByte()
            ))
            out?.write(data)
        } catch (_: Exception) {}
    }

    // ─── CETAK CUSTOMER (seluruh order) ─────────────────────────────────────
    fun printCustomer(
        queueNumber: String,
        items: List<CartItem>,
        paymentMethod: String,
        timestamp: Long
    ): Boolean = try {
        val cal     = Calendar.getInstance().apply { timeInMillis = timestamp }
        val dayName = DAYS_ID[cal.get(Calendar.DAY_OF_WEEK) - 1]
        val dateFmt = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(timestamp))
        val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(timestamp))
        val grandTotal = items.sumOf { it.totalPrice }

        b(INIT); b(ALIGN_CTR)

        // Logo toko
        printBitmap(R.drawable.logo_doyangopi, 200)
        line()
        line("ig @doyangopi4  |  tiktok @doyangopi_")
        sep()
        b(BOLD_ON); line("=== DOYANGOPI ==="); b(BOLD_OFF)
        line()

        b(ALIGN_LEFT)
        line("No   : $queueNumber")
        line("Hari : $dayName, $dateFmt")
        line("Jam  : $timeFmt")
        line()

        // List semua item
        items.forEachIndexed { i, item ->
            b(BOLD_ON)
            val shot = if (item.extraShot) " + Extra Shot" else ""
            line("${i + 1}. ${item.menu}$shot (${item.qty}x)")
            b(BOLD_OFF)
            val det = mutableListOf(item.kemanisan)
            if (item.levelEs != "-") det.add(item.levelEs)
            if (item.notes.isNotBlank()) det.add(item.notes)
            if (det.isNotEmpty()) line("   ${det.joinToString(" · ")}")
            line("   ${PriceFormatter.fmt(item.totalPrice)}")
            line()
        }

        sep()
        line("Pembayaran : $paymentMethod")
        b(BOLD_ON)
        line("TOTAL      : ${PriceFormatter.fmt(grandTotal)}")
        b(BOLD_OFF)
        sep()

        // QRIS — cetak QR image jika bayar QRIS
        if (paymentMethod == "QRIS") {
            line()
            b(ALIGN_CTR)
            line("Scan QRIS untuk membayar:")
            line()
            printBitmap(R.drawable.qris_payment, 376)
            line()
        }

        line()
        b(ALIGN_CTR); line("Terima kasih! ☕")
        line(); line(); line()
        b(CUT); out?.flush()
        true
    } catch (_: IOException) { false }

    // ─── CETAK KITCHEN (seluruh order) ──────────────────────────────────────
    fun printKitchen(
        queueNumber: String,
        items: List<CartItem>,
        timestamp: Long
    ): Boolean = try {
        val dateFmt = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(timestamp))
        val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(timestamp))

        b(INIT); b(ALIGN_CTR); b(BOLD_ON)
        line("=== DOYANGOPI KITCHEN ===")
        b(BOLD_OFF); line()
        b(ALIGN_LEFT)
        line("No   : $queueNumber")
        line("Tgl  : $dateFmt  Jam: $timeFmt")
        sep()

        items.forEachIndexed { i, item ->
            b(BOLD_ON)
            val shot = if (item.extraShot) " ★EXTRA SHOT" else ""
            line("${i + 1}. ${item.menu}$shot")
            b(BOLD_OFF)
            line("   Qty     : ${item.qty}x")
            line("   Gula    : ${item.kemanisan}")
            if (item.levelEs != "-") line("   Es      : ${item.levelEs}")
            if (item.notes.isNotBlank()) line("   Catatan : ${item.notes}")
            line()
        }

        sep()
        line(); line(); line()
        b(CUT); out?.flush()
        true
    } catch (_: IOException) { false }

    object PriceFormatter {
        fun fmt(price: Int): String = "Rp" + String.format("%,d", price).replace(',', '.')
    }
}
