package com.doyangopi.kasir.bluetooth

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.SharedPreferences
import com.doyangopi.kasir.data.Transaction
import java.io.IOException
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.*

class BluetoothPrinter(context: Context) {

    companion object {
        private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        private const val PREF = "bt_printer"
        private const val KEY_ADDR = "address"
        private const val KEY_NAME = "name"

        // ESC/POS commands
        private val INIT        = byteArrayOf(0x1B, 0x40)
        private val ALIGN_CTR   = byteArrayOf(0x1B, 0x61, 0x01)
        private val ALIGN_LEFT  = byteArrayOf(0x1B, 0x61, 0x00)
        private val BOLD_ON     = byteArrayOf(0x1B, 0x45, 0x01)
        private val BOLD_OFF    = byteArrayOf(0x1B, 0x45, 0x00)
        private val CUT         = byteArrayOf(0x1D, 0x56, 0x41, 0x10)
        private val LF          = byteArrayOf(0x0A)
    }

    private val prefs: SharedPreferences = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
    private var socket: BluetoothSocket? = null
    private var out: OutputStream? = null

    fun savedAddress(): String? = prefs.getString(KEY_ADDR, null)
    fun savedName(): String?    = prefs.getString(KEY_NAME, null)

    fun save(address: String, name: String) {
        prefs.edit().putString(KEY_ADDR, address).putString(KEY_NAME, name).apply()
    }

    @SuppressLint("MissingPermission")
    fun connect(device: BluetoothDevice): Boolean {
        return try {
            disconnect()
            socket = device.createRfcommSocketToServiceRecord(SPP_UUID)
            socket!!.connect()
            out = socket!!.outputStream
            true
        } catch (e: IOException) { disconnect(); false }
    }

    fun disconnect() {
        try { out?.close(); socket?.close() } catch (_: IOException) {}
        out = null; socket = null
    }

    fun isConnected() = socket?.isConnected == true

    private fun b(bytes: ByteArray) = out?.write(bytes)
    private fun line(text: String = "") {
        out?.write((text + "\n").toByteArray(Charsets.ISO_8859_1))
    }
    private fun sep() = line("--------------------------------")

    fun printKitchen(t: Transaction): Boolean {
        return try {
            val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(t.timestamp))
            b(INIT); b(ALIGN_CTR); b(BOLD_ON)
            line("=== DOYANGOPI ===")
            b(BOLD_OFF); line(); b(ALIGN_LEFT)
            line("No      : ${t.queueNumber}"); line()
            line("Menu    : ${t.menu}")
            if (t.beans != "-")     line("Beans   : ${t.beans}")
            if (t.levelKopi != "-") line("Kopi    : ${t.levelKopi}")
            line("Gula    : ${t.kemanisan}")
            if (t.levelEs != "-")   line("Es      : ${t.levelEs}")
            if (t.qty > 1)          line("Qty     : ${t.qty}x")
            if (t.notes.isNotBlank()) line("Catatan : ${t.notes}")
            line(); line("Jam     : $time")
            line(); line(); line()
            b(CUT); out?.flush(); true
        } catch (_: IOException) { false }
    }

    fun printCustomer(t: Transaction): Boolean {
        return try {
            val total = "Rp" + String.format("%,d", t.totalPrice).replace(',', '.')
            b(INIT); b(ALIGN_CTR); b(BOLD_ON)
            line("=== DOYANGOPI ===")
            b(BOLD_OFF); line(); b(ALIGN_LEFT)
            line("No : ${t.queueNumber}"); line()
            b(BOLD_ON); line("${t.menu}${if (t.levelKopi != "-") " (${t.levelKopi})" else ""}"); b(BOLD_OFF)
            if (t.beans != "-") line(t.beans)
            if (t.qty > 1) line("${t.qty}x")
            if (t.notes.isNotBlank()) line("Catatan: ${t.notes}")
            line(); sep()
            line("Total   : $total")
            sep(); line(); b(ALIGN_CTR)
            line("Terima kasih!")
            line(); line(); line()
            b(CUT); out?.flush(); true
        } catch (_: IOException) { false }
    }
}
