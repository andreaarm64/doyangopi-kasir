package com.doyangopi.kasir.data

data class Expense(
    val id: Long = 0,
    val date: String,           // format: "2026-07-06"
    val category: String,
    val description: String,
    val amount: Int,
    val timestamp: Long = System.currentTimeMillis()
)
