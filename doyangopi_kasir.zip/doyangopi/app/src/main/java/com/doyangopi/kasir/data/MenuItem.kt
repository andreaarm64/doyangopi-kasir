package com.doyangopi.kasir.data

data class MenuItem(
    val id: Long = 0,
    val name: String,
    val price: Int,
    val hpp: Int = 0,
    val allowExtraShot: Boolean = true,
    val sortOrder: Int = 0
)
