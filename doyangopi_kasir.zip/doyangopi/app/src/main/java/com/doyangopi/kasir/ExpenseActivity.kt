package com.doyangopi.kasir

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.doyangopi.kasir.data.DatabaseHelper
import com.doyangopi.kasir.data.Expense
import com.doyangopi.kasir.databinding.ActivityExpenseBinding
import com.doyangopi.kasir.util.PriceCalculator
import java.text.SimpleDateFormat
import java.util.*

class ExpenseActivity : AppCompatActivity() {

    private lateinit var binding: ActivityExpenseBinding
    private lateinit var db: DatabaseHelper
    private var currentPeriod = "today"
    private var expenses = listOf<Expense>()

    private val categories = listOf(
        "Bahan Baku", "Gas & Listrik", "Kemasan & Alat",
        "Transportasi", "Gaji / Honor", "Lain-lain"
    )
    private val DAY_NAMES = arrayOf("Min","Sen","Sel","Rab","Kam","Jum","Sab")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityExpenseBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.title = "Pengeluaran"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        db = DatabaseHelper(this)
        setupPeriodButtons()
        loadExpenses("today")

        binding.btnAddExpense.setOnClickListener { showAddDialog() }
    }

    // ─── PERIOD ────────────────────────────────────────────────────────────

    private fun setupPeriodButtons() {
        binding.btnExpToday.setOnClickListener { loadExpenses("today") }
        binding.btnExpWeek.setOnClickListener  { loadExpenses("week")  }
        binding.btnExpMonth.setOnClickListener { loadExpenses("month") }
    }

    private fun setPeriodUI(period: String) {
        val gold  = ContextCompat.getColorStateList(this, R.color.coffee_gold)
        val blue  = ContextCompat.getColorStateList(this, R.color.medium_blue)
        listOf(binding.btnExpToday to "today", binding.btnExpWeek to "week", binding.btnExpMonth to "month")
            .forEach { (btn, p) ->
                btn.backgroundTintList = if (p == period) gold else blue
                btn.setTextColor(if (p == period) ContextCompat.getColor(this, R.color.dark_navy) else Color.WHITE)
            }
    }

    // ─── LOAD ──────────────────────────────────────────────────────────────

    private fun loadExpenses(period: String) {
        currentPeriod = period
        setPeriodUI(period)
        expenses = when (period) {
            "week"  -> db.getWeekExpenses()
            "month" -> db.getMonthExpenses()
            else    -> db.getTodayExpenses()
        }
        updateSummary()
        buildExpenseList()
    }

    // ─── SUMMARY ───────────────────────────────────────────────────────────

    private fun updateSummary() {
        val total = expenses.sumOf { it.amount }
        binding.tvExpTotal.text = "Total: ${PriceCalculator.format(total)}"

        val catBreakdown = expenses.groupBy { it.category }
            .mapValues { e -> e.value.sumOf { it.amount } }
            .entries.sortedByDescending { it.value }

        binding.tvExpCategoryBreakdown.text =
            if (catBreakdown.isEmpty()) ""
            else catBreakdown.joinToString("\n") { "  ${it.key}: ${PriceCalculator.format(it.value)}" }
    }

    // ─── EXPENSE LIST (grouped by date) ───────────────────────────────────

    private fun buildExpenseList() {
        val container = binding.layoutExpenseList
        container.removeAllViews()

        if (expenses.isEmpty()) {
            binding.tvExpEmpty.visibility = View.VISIBLE
            return
        }
        binding.tvExpEmpty.visibility = View.GONE

        val sdfDisp = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())

        // Group by date string
        val grouped = expenses.groupBy { it.date }.toSortedMap()

        grouped.forEach { (_, dayExpenses) ->
            val cal = Calendar.getInstance().apply { timeInMillis = dayExpenses.first().timestamp }
            val dayName = DAY_NAMES[cal.get(Calendar.DAY_OF_WEEK) - 1]
            val dateDisp = sdfDisp.format(cal.time)
            val dayTotal = dayExpenses.sumOf { it.amount }

            // Date header
            container.addView(TextView(this).apply {
                text = "📅 $dayName, $dateDisp  —  ${PriceCalculator.format(dayTotal)}"
                setTextColor(Color.parseColor("#FF9999"))
                textSize = 12f
                setTypeface(null, Typeface.BOLD)
                setPadding(0, dp(10), 0, dp(4))
                layoutParams = llParams(matchParent = true)
            })

            // Expense rows
            dayExpenses.forEach { exp ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    layoutParams = llParams(matchParent = true, bMargin = dp(4))
                    setPadding(dp(8), dp(2), 0, dp(2))
                }

                // Category badge + description
                val info = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                info.addView(TextView(this).apply {
                    text = exp.category
                    setTextColor(Color.parseColor("#F5CBA7"))
                    textSize = 10f
                    setTypeface(null, Typeface.BOLD)
                })
                info.addView(TextView(this).apply {
                    text = exp.description
                    setTextColor(Color.WHITE)
                    textSize = 12f
                })
                row.addView(info)

                // Amount
                row.addView(TextView(this).apply {
                    text = PriceCalculator.format(exp.amount)
                    setTextColor(Color.parseColor("#FF9999"))
                    textSize = 12f
                    textStyle(Typeface.BOLD)
                    gravity = Gravity.END
                    layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(4) }
                })

                // Delete button
                row.addView(TextView(this).apply {
                    text = "🗑"
                    textSize = 14f
                    gravity = Gravity.CENTER
                    layoutParams = LinearLayout.LayoutParams(dp(36), dp(36))
                    setOnClickListener { confirmDelete(exp) }
                })

                container.addView(row)
            }
            container.addView(divider())
        }
    }

    private fun TextView.textStyle(style: Int) = setTypeface(null, style)

    // ─── ADD DIALOG ────────────────────────────────────────────────────────

    private fun showAddDialog() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(8))
        }

        fun label(text: String) = TextView(this).apply {
            this.text = text; textSize = 12f
            setTextColor(Color.parseColor("#AAAAAA"))
            setPadding(0, dp(10), 0, dp(4))
        }

        // Category
        layout.addView(label("Kategori"))
        val spinnerCat = Spinner(this)
        val catAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, categories)
        catAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerCat.adapter = catAdapter
        layout.addView(spinnerCat)

        // Description
        layout.addView(label("Keterangan"))
        val etDesc = EditText(this).apply {
            hint = "Contoh: Beli kopi robusta 1kg"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        layout.addView(etDesc)

        // Amount
        layout.addView(label("Nominal (Rp)"))
        val etAmount = EditText(this).apply {
            hint = "Contoh: 25000"
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        layout.addView(etAmount)

        AlertDialog.Builder(this)
            .setTitle("Tambah Pengeluaran")
            .setView(layout)
            .setPositiveButton("Simpan") { _, _ ->
                val cat    = categories[spinnerCat.selectedItemPosition]
                val desc   = etDesc.text.toString().trim()
                val amount = etAmount.text.toString().trim().toIntOrNull() ?: 0
                if (desc.isBlank() || amount <= 0) {
                    Toast.makeText(this, "Isi keterangan dan nominal dengan benar", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
                db.insertExpense(Expense(date = dateStr, category = cat, description = desc, amount = amount))
                loadExpenses(currentPeriod)
                Toast.makeText(this, "✅ Pengeluaran dicatat", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun confirmDelete(exp: Expense) {
        AlertDialog.Builder(this)
            .setTitle("Hapus pengeluaran ini?")
            .setMessage("${exp.category} — ${exp.description}\n${PriceCalculator.format(exp.amount)}")
            .setPositiveButton("Hapus") { _, _ ->
                if (db.deleteExpense(exp.id)) {
                    loadExpenses(currentPeriod)
                    Toast.makeText(this, "✅ Dihapus", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Batal", null).show()
    }

    // ─── HELPERS ───────────────────────────────────────────────────────────

    private fun dp(n: Int) = (n * resources.displayMetrics.density + 0.5f).toInt()
    private val matchParent = LinearLayout.LayoutParams.MATCH_PARENT
    private val lp_wrap     = LinearLayout.LayoutParams.WRAP_CONTENT

    private fun llParams(matchParent: Boolean = false, bMargin: Int = 0) =
        LinearLayout.LayoutParams(if (matchParent) this.matchParent else lp_wrap, lp_wrap)
            .apply { bottomMargin = bMargin }

    private fun divider() = View(this).apply {
        setBackgroundColor(Color.parseColor("#2A2A4A"))
        layoutParams = LinearLayout.LayoutParams(matchParent, 1).apply { bottomMargin = dp(6); topMargin = dp(6) }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}
