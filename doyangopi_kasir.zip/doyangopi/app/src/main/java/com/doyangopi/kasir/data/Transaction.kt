package com.doyangopi.kasir.data

data class Transaction(
    val id: Long = 0,
    val queueNumber: String,
    val menu: String,
    val beans: String,
    val levelKopi: String,
    val kemanisan: String,
    val levelEs: String,
    val qty: Int,
    val notes: String,
    val pricePerItem: Int,
    val totalPrice: Int,
    val timestamp: Long = System.currentTimeMillis()
)
