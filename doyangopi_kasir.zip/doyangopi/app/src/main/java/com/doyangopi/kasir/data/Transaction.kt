package com.doyangopi.kasir.data

data class Transaction(
    val id: Long = 0,
    val queueNumber: String,
    val menu: String,
    val kemanisan: String,
    val levelEs: String,
    val extraShot: Boolean,
    val qty: Int,
    val notes: String,
    val pricePerItem: Int,
    val totalPrice: Int,
    val paymentMethod: String = "Cash",
    val timestamp: Long = System.currentTimeMillis()
)
