package com.doyangopi.kasir.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.util.Calendar

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {

    companion object {
        private const val DB_NAME    = "doyangopi.db"
        private const val DB_VERSION = 1
        const val TABLE          = "transactions"
        const val COL_ID         = "id"
        const val COL_QUEUE      = "queue_number"
        const val COL_MENU       = "menu"
        const val COL_BEANS      = "beans"
        const val COL_LEVEL_KOPI = "level_kopi"
        const val COL_KEMANISAN  = "kemanisan"
        const val COL_LEVEL_ES   = "level_es"
        const val COL_QTY        = "qty"
        const val COL_NOTES      = "notes"
        const val COL_PRICE_ITEM = "price_per_item"
        const val COL_TOTAL      = "total_price"
        const val COL_TIMESTAMP  = "timestamp"
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE $TABLE (
                $COL_ID         INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_QUEUE      TEXT    NOT NULL,
                $COL_MENU       TEXT    NOT NULL,
                $COL_BEANS      TEXT    NOT NULL,
                $COL_LEVEL_KOPI TEXT    NOT NULL,
                $COL_KEMANISAN  TEXT    NOT NULL,
                $COL_LEVEL_ES   TEXT    NOT NULL,
                $COL_QTY        INTEGER NOT NULL,
                $COL_NOTES      TEXT,
                $COL_PRICE_ITEM INTEGER NOT NULL,
                $COL_TOTAL      INTEGER NOT NULL,
                $COL_TIMESTAMP  INTEGER NOT NULL
            )
        """.trimIndent())
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE")
        onCreate(db)
    }

    fun insert(t: Transaction): Long {
        val cv = ContentValues().apply {
            put(COL_QUEUE,      t.queueNumber)
            put(COL_MENU,       t.menu)
            put(COL_BEANS,      t.beans)
            put(COL_LEVEL_KOPI, t.levelKopi)
            put(COL_KEMANISAN,  t.kemanisan)
            put(COL_LEVEL_ES,   t.levelEs)
            put(COL_QTY,        t.qty)
            put(COL_NOTES,      t.notes)
            put(COL_PRICE_ITEM, t.pricePerItem)
            put(COL_TOTAL,      t.totalPrice)
            put(COL_TIMESTAMP,  t.timestamp)
        }
        return writableDatabase.insert(TABLE, null, cv)
    }

    fun deleteTransaction(id: Long): Boolean =
        writableDatabase.delete(TABLE, "$COL_ID = ?", arrayOf(id.toString())) > 0

    fun getTodayTransactions(): List<Transaction> {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0);      set(Calendar.MILLISECOND, 0)
        }
        val start = cal.timeInMillis
        cal.add(Calendar.DAY_OF_MONTH, 1)
        val end = cal.timeInMillis
        return queryRange(start, end)
    }

    private fun queryRange(start: Long, end: Long): List<Transaction> {
        val cursor = readableDatabase.query(
            TABLE, null,
            "$COL_TIMESTAMP >= ? AND $COL_TIMESTAMP < ?",
            arrayOf(start.toString(), end.toString()),
            null, null, "$COL_TIMESTAMP ASC"
        )
        val list = mutableListOf<Transaction>()
        cursor.use {
            while (it.moveToNext()) {
                list.add(Transaction(
                    id           = it.getLong(it.getColumnIndexOrThrow(COL_ID)),
                    queueNumber  = it.getString(it.getColumnIndexOrThrow(COL_QUEUE)),
                    menu         = it.getString(it.getColumnIndexOrThrow(COL_MENU)),
                    beans        = it.getString(it.getColumnIndexOrThrow(COL_BEANS)),
                    levelKopi    = it.getString(it.getColumnIndexOrThrow(COL_LEVEL_KOPI)),
                    kemanisan    = it.getString(it.getColumnIndexOrThrow(COL_KEMANISAN)),
                    levelEs      = it.getString(it.getColumnIndexOrThrow(COL_LEVEL_ES)),
                    qty          = it.getInt(it.getColumnIndexOrThrow(COL_QTY)),
                    notes        = it.getString(it.getColumnIndexOrThrow(COL_NOTES)) ?: "",
                    pricePerItem = it.getInt(it.getColumnIndexOrThrow(COL_PRICE_ITEM)),
                    totalPrice   = it.getInt(it.getColumnIndexOrThrow(COL_TOTAL)),
                    timestamp    = it.getLong(it.getColumnIndexOrThrow(COL_TIMESTAMP))
                ))
            }
        }
        return list
    }

    // Format: [MonthLetter][NomorUrut] — angka berlanjut sepanjang bulan, reset tiap bulan baru
    // Januari=A, Februari=B, ..., Desember=L
    fun nextQueueNumber(): String {
        val cal = Calendar.getInstance()
        val monthLetter = ('A' + cal.get(Calendar.MONTH)).toString()  // MONTH is 0-based

        // Hitung semua transaksi bulan ini
        cal.set(Calendar.DAY_OF_MONTH, 1)
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0);      cal.set(Calendar.MILLISECOND, 0)
        val startOfMonth = cal.timeInMillis

        val cursor = readableDatabase.rawQuery(
            "SELECT COUNT(*) FROM $TABLE WHERE $COL_TIMESTAMP >= ?",
            arrayOf(startOfMonth.toString())
        )
        cursor.use {
            it.moveToFirst()
            val count = it.getInt(0) + 1
            return "$monthLetter${count.toString().padStart(3, '0')}"
        }
    }
}
