package com.doyangopi.kasir.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.util.Calendar

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {

    companion object {
        private const val DB_NAME    = "doyangopi.db"
        private const val DB_VERSION = 2
        const val TABLE          = "transactions"
        const val COL_ID         = "id"
        const val COL_QUEUE      = "queue_number"
        const val COL_MENU       = "menu"
        const val COL_KEMANISAN  = "kemanisan"
        const val COL_LEVEL_ES   = "level_es"
        const val COL_EXTRA_SHOT = "extra_shot"
        const val COL_QTY        = "qty"
        const val COL_NOTES      = "notes"
        const val COL_PRICE_ITEM = "price_per_item"
        const val COL_TOTAL      = "total_price"
        const val COL_PAYMENT    = "payment_method"
        const val COL_TIMESTAMP  = "timestamp"
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE $TABLE (
                $COL_ID         INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_QUEUE      TEXT    NOT NULL,
                $COL_MENU       TEXT    NOT NULL,
                $COL_KEMANISAN  TEXT    NOT NULL,
                $COL_LEVEL_ES   TEXT    NOT NULL,
                $COL_EXTRA_SHOT INTEGER NOT NULL DEFAULT 0,
                $COL_QTY        INTEGER NOT NULL,
                $COL_NOTES      TEXT,
                $COL_PRICE_ITEM INTEGER NOT NULL,
                $COL_TOTAL      INTEGER NOT NULL,
                $COL_PAYMENT    TEXT    NOT NULL DEFAULT 'Cash',
                $COL_TIMESTAMP  INTEGER NOT NULL
            )
        """.trimIndent())
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE")
        onCreate(db)
    }

    fun insert(t: Transaction): Long {
        val cv = ContentValues().apply {
            put(COL_QUEUE,      t.queueNumber)
            put(COL_MENU,       t.menu)
            put(COL_KEMANISAN,  t.kemanisan)
            put(COL_LEVEL_ES,   t.levelEs)
            put(COL_EXTRA_SHOT, if (t.extraShot) 1 else 0)
            put(COL_QTY,        t.qty)
            put(COL_NOTES,      t.notes)
            put(COL_PRICE_ITEM, t.pricePerItem)
            put(COL_TOTAL,      t.totalPrice)
            put(COL_PAYMENT,    t.paymentMethod)
            put(COL_TIMESTAMP,  t.timestamp)
        }
        return writableDatabase.insert(TABLE, null, cv)
    }

    fun deleteTransaction(id: Long): Boolean =
        writableDatabase.delete(TABLE, "$COL_ID = ?", arrayOf(id.toString())) > 0

    // ─── QUERY HELPERS ──────────────────────────────────────────────────────

    private fun startOfDay(cal: Calendar = Calendar.getInstance()): Long {
        return cal.apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0);      set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }

    fun getTodayTransactions(): List<Transaction> {
        val start = startOfDay()
        val cal = Calendar.getInstance().apply { timeInMillis = start }
        cal.add(Calendar.DAY_OF_MONTH, 1)
        return queryRange(start, cal.timeInMillis)
    }

    fun getWeekTransactions(): List<Transaction> {
        val cal = Calendar.getInstance()
        // Mundur ke Senin
        while (cal.get(Calendar.DAY_OF_WEEK) != Calendar.MONDAY)
            cal.add(Calendar.DAY_OF_MONTH, -1)
        val start = startOfDay(cal)
        cal.add(Calendar.DAY_OF_MONTH, 7)
        return queryRange(start, cal.timeInMillis)
    }

    fun getMonthTransactions(): List<Transaction> {
        val cal = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_MONTH, 1)
        }
        val start = startOfDay(cal)
        cal.add(Calendar.MONTH, 1)
        return queryRange(start, cal.timeInMillis)
    }

    fun queryRange(start: Long, end: Long): List<Transaction> {
        val cursor = readableDatabase.query(
            TABLE, null,
            "$COL_TIMESTAMP >= ? AND $COL_TIMESTAMP < ?",
            arrayOf(start.toString(), end.toString()),
            null, null, "$COL_TIMESTAMP ASC"
        )
        val list = mutableListOf<Transaction>()
        cursor.use {
            while (it.moveToNext()) {
                list.add(Transaction(
                    id            = it.getLong(it.getColumnIndexOrThrow(COL_ID)),
                    queueNumber   = it.getString(it.getColumnIndexOrThrow(COL_QUEUE)),
                    menu          = it.getString(it.getColumnIndexOrThrow(COL_MENU)),
                    kemanisan     = it.getString(it.getColumnIndexOrThrow(COL_KEMANISAN)),
                    levelEs       = it.getString(it.getColumnIndexOrThrow(COL_LEVEL_ES)),
                    extraShot     = it.getInt(it.getColumnIndexOrThrow(COL_EXTRA_SHOT)) == 1,
                    qty           = it.getInt(it.getColumnIndexOrThrow(COL_QTY)),
                    notes         = it.getString(it.getColumnIndexOrThrow(COL_NOTES)) ?: "",
                    pricePerItem  = it.getInt(it.getColumnIndexOrThrow(COL_PRICE_ITEM)),
                    totalPrice    = it.getInt(it.getColumnIndexOrThrow(COL_TOTAL)),
                    paymentMethod = it.getString(it.getColumnIndexOrThrow(COL_PAYMENT)) ?: "Cash",
                    timestamp     = it.getLong(it.getColumnIndexOrThrow(COL_TIMESTAMP))
                ))
            }
        }
        return list
    }

    fun nextQueueNumber(): String {
        val cal = Calendar.getInstance()
        val monthLetter = ('A' + cal.get(Calendar.MONTH)).toString()
        cal.set(Calendar.DAY_OF_MONTH, 1)
        val start = startOfDay(cal)
        val cursor = readableDatabase.rawQuery(
            "SELECT COUNT(DISTINCT $COL_QUEUE) FROM $TABLE WHERE $COL_TIMESTAMP >= ?",
            arrayOf(start.toString())
        )
        cursor.use {
            it.moveToFirst()
            return "$monthLetter${(it.getInt(0) + 1).toString().padStart(3, '0')}"
        }
    }
}
