package com.doyangopi.kasir

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.doyangopi.kasir.data.Transaction
import com.doyangopi.kasir.util.PriceCalculator
import java.text.SimpleDateFormat
import java.util.*

class TransactionAdapter(
    private val items: MutableList<Transaction>,
    private val onDeleteClick: (Transaction, Int) -> Unit
) : RecyclerView.Adapter<TransactionAdapter.VH>() {

    private val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val tvTime   : TextView = view.findViewById(R.id.tvItemTime)
        val tvQueue  : TextView = view.findViewById(R.id.tvItemQueue)
        val tvMenu   : TextView = view.findViewById(R.id.tvItemMenu)
        val tvDetail : TextView = view.findViewById(R.id.tvItemDetail)
        val tvPrice  : TextView = view.findViewById(R.id.tvItemPrice)
        val btnDelete: TextView = view.findViewById(R.id.btnDeleteItem)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_transaction, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val t = items[position]
        holder.tvTime.text  = sdf.format(Date(t.timestamp))
        holder.tvQueue.text = t.queueNumber

        val menuLabel = if (t.levelKopi != "-") "${t.menu} (${t.levelKopi})" else t.menu
        holder.tvMenu.text = menuLabel

        val detailParts = mutableListOf<String>()
        if (t.beans != "-")       detailParts.add(t.beans)
        if (t.qty > 1)            detailParts.add("${t.qty}x")
        if (t.notes.isNotBlank()) detailParts.add(t.notes)
        holder.tvDetail.text = detailParts.joinToString(" · ")

        holder.tvPrice.text = PriceCalculator.format(t.totalPrice)

        holder.btnDelete.setOnClickListener {
            val pos = holder.adapterPosition
            if (pos != RecyclerView.NO_ID.toInt()) onDeleteClick(t, pos)
        }
    }

    override fun getItemCount() = items.size

    fun removeAt(position: Int) {
        items.removeAt(position)
        notifyItemRemoved(position)
    }

    fun replaceAll(newItems: List<Transaction>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }
}
