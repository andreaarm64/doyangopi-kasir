package com.doyangopi.kasir

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.doyangopi.kasir.data.Transaction
import com.doyangopi.kasir.util.PriceCalculator
import java.text.SimpleDateFormat
import java.util.*

class TransactionAdapter(
    private val items: MutableList<Transaction>,
    private val onDelete: (Transaction, Int) -> Unit
) : RecyclerView.Adapter<TransactionAdapter.VH>() {

    private val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tvTime   : TextView = v.findViewById(R.id.tvItemTime)
        val tvQueue  : TextView = v.findViewById(R.id.tvItemQueue)
        val tvMenu   : TextView = v.findViewById(R.id.tvItemMenu)
        val tvDetail : TextView = v.findViewById(R.id.tvItemDetail)
        val tvPrice  : TextView = v.findViewById(R.id.tvItemPrice)
        val btnDelete: TextView = v.findViewById(R.id.btnDeleteItem)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_transaction, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val t = items[position]
        holder.tvTime.text  = sdf.format(Date(t.timestamp))
        holder.tvQueue.text = "${t.queueNumber} · ${t.paymentMethod}"

        val shot = if (t.extraShot) " + Shot" else ""
        holder.tvMenu.text = "${t.menu}$shot"

        val parts = mutableListOf(t.kemanisan)
        if (t.levelEs != "-") parts.add("Es: ${t.levelEs}")
        if (t.qty > 1) parts.add("${t.qty}x")
        if (t.notes.isNotBlank()) parts.add(t.notes)
        holder.tvDetail.text = parts.joinToString(" · ")

        holder.tvPrice.text = PriceCalculator.format(t.totalPrice)
        holder.btnDelete.setOnClickListener {
            val pos = holder.adapterPosition
            if (pos != RecyclerView.NO_ID.toInt()) onDelete(t, pos)
        }
    }

    override fun getItemCount() = items.size

    fun removeAt(pos: Int) { items.removeAt(pos); notifyItemRemoved(pos) }
    fun replaceAll(newItems: List<Transaction>) {
        items.clear(); items.addAll(newItems); notifyDataSetChanged()
    }
}
