package com.doyangopi.kasir

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.doyangopi.kasir.bluetooth.BluetoothPrinter
import com.doyangopi.kasir.data.CartItem
import com.doyangopi.kasir.databinding.ActivityMainBinding
import com.doyangopi.kasir.util.PriceCalculator
import com.doyangopi.kasir.util.MenuCache
import kotlinx.coroutines.*

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var printer: BluetoothPrinter
    private lateinit var cartAdapter: CartAdapter
    private val cart = mutableListOf<CartItem>()
    private val scope = CoroutineScope(Dispatchers.Main + Job())
    private var qty = 1

    private var menus = listOf<String>()

    companion object { private const val BT_REQ = 100 }

    private val checkoutLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            cart.clear()
            cartAdapter.notifyDataSetChanged()
            updateCartUI()
            Toast.makeText(this, "✅ Order selesai & tersimpan!", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.title = "DOYANGOPI — POS"

        printer = BluetoothPrinter(this)
        MenuCache.load(this)
        setupMenu()
        setupCart()
        setupListeners()
        updatePrice()
        updatePrinterStatus()
    }

    private fun setupMenu() {
        menus = PriceCalculator.ALL_MENUS
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, menus)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerMenu.adapter = adapter

        binding.spinnerMenu.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(p: AdapterView<*>?) {}
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                val m = menus[pos]

                // Level Es: sembunyikan untuk semua varian Hot
                binding.cardLevelEs.visibility = if (PriceCalculator.isHot(m)) View.GONE else View.VISIBLE

                // Extra Shot: sembunyikan untuk item yang tidak mengizinkan (lihat PriceCalculator)
                val showExtraShot = PriceCalculator.allowsExtraShot(m)
                binding.cardExtraShot.visibility = if (showExtraShot) View.VISIBLE else View.GONE
                if (!showExtraShot) binding.cbExtraShot.isChecked = false

                updatePrice()
            }
        }
    }

    private fun setupCart() {
        cartAdapter = CartAdapter(cart) { pos ->
            cart.removeAt(pos)
            cartAdapter.notifyItemRemoved(pos)
            updateCartUI()
        }
        binding.rvCart.layoutManager = LinearLayoutManager(this)
        binding.rvCart.adapter = cartAdapter
        binding.rvCart.isNestedScrollingEnabled = false
    }

    private fun setupListeners() {
        binding.btnQtyMinus.setOnClickListener {
            if (qty > 1) { qty--; binding.tvQty.text = qty.toString(); updatePrice() }
        }
        binding.btnQtyPlus.setOnClickListener {
            qty++; binding.tvQty.text = qty.toString(); updatePrice()
        }
        binding.rgKemanisan.setOnCheckedChangeListener { _, _ -> updatePrice() }
        binding.cbExtraShot.setOnCheckedChangeListener { _, _ -> updatePrice() }
        binding.cbUpsize.setOnCheckedChangeListener             { _, _ -> updatePrice() }
        binding.cbOatmilk.setOnCheckedChangeListener            { _, _ -> updatePrice() }
        binding.cbCaramelSauce.setOnCheckedChangeListener       { _, _ -> updatePrice() }
        binding.cbButterscotchSauce.setOnCheckedChangeListener  { _, _ -> updatePrice() }

        binding.btnTambah.setOnClickListener   { addToCart() }
        binding.btnCheckout.setOnClickListener {
            if (cart.isEmpty()) return@setOnClickListener
            val intent = Intent(this, CheckoutActivity::class.java)
            intent.putExtra("cart", ArrayList(cart))
            checkoutLauncher.launch(intent)
        }
        binding.btnLaporan.setOnClickListener     { startActivity(Intent(this, ReportActivity::class.java)) }
        binding.btnPengeluaran.setOnClickListener  { startActivity(Intent(this, ExpenseActivity::class.java)) }
        binding.btnPrinter.setOnClickListener  { selectPrinter() }
    }

    private fun menu() = menus[binding.spinnerMenu.selectedItemPosition]
    private fun gula() = when {
        binding.rbNormalGula.isChecked -> "Normal"
        binding.rbLessGula.isChecked   -> "Less"
        binding.rbNoGula.isChecked     -> "No Sugar"
        else                           -> "Custom"
    }
    private fun es() = when {
        binding.rbNormalEs.isChecked -> "Normal"
        binding.rbLessEs.isChecked   -> "Less"
        else                         -> "No Ice"
    }

    private fun selectedAddOns(): List<String> {
        val list = mutableListOf<String>()
        if (binding.cbUpsize.isChecked)            list.add("Upsize (16oz)")
        if (binding.cbOatmilk.isChecked)            list.add("Oatmilk")
        if (binding.cbCaramelSauce.isChecked)       list.add("Caramel Sauce")
        if (binding.cbButterscotchSauce.isChecked)  list.add("Butterscotch Sauce")
        return list
    }

    private fun updatePrice() {
        val m       = menu()
        val extra   = binding.cbExtraShot.isChecked && PriceCalculator.allowsExtraShot(m)
        val addOns  = selectedAddOns()
        binding.tvHarga.text = PriceCalculator.format(PriceCalculator.calculate(m, extra, qty, addOns))
    }

    private fun addToCart() {
        val m         = menu()
        val extra     = binding.cbExtraShot.isChecked && PriceCalculator.allowsExtraShot(m)
        val le        = if (PriceCalculator.isHot(m)) "-" else es()
        val notes     = binding.etCatatan.text.toString().trim()
        val addOns    = selectedAddOns()
        val perItem   = PriceCalculator.pricePerItem(m, extra, addOns)

        val item = CartItem(
            menu         = m,
            kemanisan    = gula(),
            levelEs      = le,
            extraShot    = extra,
            qty          = qty,
            notes        = notes,
            pricePerItem = perItem,
            totalPrice   = perItem * qty,
            addOns       = addOns
        )
        cart.add(item)
        cartAdapter.notifyItemInserted(cart.size - 1)
        updateCartUI()
        resetForm()
        Toast.makeText(this, "✅ Ditambahkan ke pesanan", Toast.LENGTH_SHORT).show()
    }

    private fun updateCartUI() {
        val isEmpty = cart.isEmpty()
        binding.tvCartEmpty.visibility = if (isEmpty) View.VISIBLE else View.GONE
        binding.rvCart.visibility      = if (isEmpty) View.GONE else View.VISIBLE
        binding.tvCartTotal.text       = PriceCalculator.format(cart.sumOf { it.totalPrice })
        binding.btnCheckout.isEnabled  = !isEmpty
        binding.btnCheckout.alpha      = if (isEmpty) 0.4f else 1f
    }

    private fun resetForm() {
        binding.spinnerMenu.setSelection(0)
        binding.rbNormalGula.isChecked = true
        binding.rbNormalEs.isChecked   = true
        binding.cbExtraShot.isChecked  = false
        binding.cbUpsize.isChecked            = false
        binding.cbOatmilk.isChecked           = false
        binding.cbCaramelSauce.isChecked      = false
        binding.cbButterscotchSauce.isChecked = false
        qty = 1; binding.tvQty.text = "1"
        binding.etCatatan.text?.clear()
        updatePrice()
    }

    @SuppressLint("MissingPermission")
    private fun selectPrinter() {
        if (!checkBtPermissions()) return
        val bm = getSystemService(BluetoothManager::class.java)
        if (bm?.adapter?.isEnabled != true) {
            Toast.makeText(this, "Aktifkan Bluetooth terlebih dahulu", Toast.LENGTH_SHORT).show()
            return
        }
        val paired = bm.adapter.bondedDevices.toList()
        if (paired.isEmpty()) {
            Toast.makeText(this, "Pair printer RPP02N dulu via Pengaturan Bluetooth", Toast.LENGTH_LONG).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Pilih Printer Bluetooth")
            .setItems(paired.map { "${it.name}\n${it.address}" }.toTypedArray()) { _, i ->
                val dev = paired[i]
                printer.save(dev.address, dev.name ?: "Printer")
                scope.launch {
                    val ok = withContext(Dispatchers.IO) { printer.connect(dev) }
                    Toast.makeText(this@MainActivity,
                        if (ok) "✅ Terhubung ke ${dev.name}" else "❌ Gagal konek",
                        Toast.LENGTH_SHORT).show()
                    updatePrinterStatus()
                }
            }.show()
    }

    private fun updatePrinterStatus() {
        val name = printer.savedName()
        binding.tvPrinterStatus.text =
            if (name != null) "Printer: $name ${if (printer.isConnected()) "🟢" else "⚪"}"
            else "Printer: Belum dipilih"
    }

    private fun checkBtPermissions(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN),
                BT_REQ)
            return false
        }
        return true
    }

    override fun onRequestPermissionsResult(req: Int, perms: Array<String>, results: IntArray) {
        super.onRequestPermissionsResult(req, perms, results)
        if (req == BT_REQ && results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED)
            selectPrinter()
    }

    override fun onResume() {
        super.onResume()
        updatePrinterStatus()
        MenuCache.load(this)
        setupMenu()
        binding.spinnerMenu.setSelection(0)
        updatePrice()
    }
    override fun onDestroy() { super.onDestroy(); scope.cancel() }
}
