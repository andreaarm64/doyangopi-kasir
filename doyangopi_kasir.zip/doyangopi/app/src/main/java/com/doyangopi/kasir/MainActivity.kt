package com.doyangopi.kasir

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.doyangopi.kasir.bluetooth.BluetoothPrinter
import com.doyangopi.kasir.data.DatabaseHelper
import com.doyangopi.kasir.data.Transaction
import com.doyangopi.kasir.databinding.ActivityMainBinding
import com.doyangopi.kasir.util.PriceCalculator
import kotlinx.coroutines.*

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var db: DatabaseHelper
    private lateinit var printer: BluetoothPrinter
    private val scope = CoroutineScope(Dispatchers.Main + Job())
    private var qty = 1

    private val menus = listOf(
        "Es Kopi Susu", "Es Kopi Latte", "Es Kopi Hitam", "Mokapot Ice", "Mokapot Hot"
    )

    companion object { private const val BT_REQ = 100 }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.title = "DOYANGOPI — POS"

        db      = DatabaseHelper(this)
        printer = BluetoothPrinter(this)

        setupMenu()
        setupListeners()
        updatePrice()
        updatePrinterStatus()
    }

    private fun setupMenu() {
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, menus)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerMenu.adapter = adapter

        binding.spinnerMenu.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(p: AdapterView<*>?) {}
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                val m = menus[pos]
                val isMokapot = PriceCalculator.isMokapot(m)
                binding.cardBeans.visibility     = if (isMokapot) View.GONE else View.VISIBLE
                binding.cardLevelKopi.visibility = if (isMokapot) View.GONE else View.VISIBLE
                binding.cardLevelEs.visibility   = if (m == "Mokapot Hot") View.GONE else View.VISIBLE
                updatePrice()
            }
        }
    }

    private fun setupListeners() {
        binding.btnQtyMinus.setOnClickListener {
            if (qty > 1) { qty--; binding.tvQty.text = qty.toString(); updatePrice() }
        }
        binding.btnQtyPlus.setOnClickListener {
            qty++; binding.tvQty.text = qty.toString(); updatePrice()
        }
        binding.rgBeans.setOnCheckedChangeListener    { _, _ -> updatePrice() }
        binding.rgLevelKopi.setOnCheckedChangeListener { _, _ -> updatePrice() }
        binding.btnProses.setOnClickListener  { processOrder() }
        binding.btnLaporan.setOnClickListener {
            startActivity(Intent(this, ReportActivity::class.java))
        }
        binding.btnPrinter.setOnClickListener { selectPrinter() }
    }

    private fun menu()      = menus[binding.spinnerMenu.selectedItemPosition]
    private fun beans()     = if (binding.rbRobusta.isChecked) "Robusta" else "Arabica"
    private fun levelKopi() = if (binding.rbNormalKopi.isChecked) "Normal" else "Strong"
    private fun gula() = when {
        binding.rbNormalGula.isChecked  -> "Normal"
        binding.rbLessGula.isChecked    -> "Less"
        binding.rbNoGula.isChecked      -> "No Sugar"
        else                            -> "Custom"
    }
    private fun es() = when {
        binding.rbNormalEs.isChecked -> "Normal"
        binding.rbLessEs.isChecked   -> "Less"
        binding.rbFullEs.isChecked   -> "Full"
        else                         -> "No Ice"
    }

    private fun updatePrice() {
        val m = menu()
        val price = PriceCalculator.calculate(m, beans(), levelKopi()) * qty
        binding.tvHarga.text = PriceCalculator.format(price)
    }

    private fun processOrder() {
        val m         = menu()
        val isMokapot = PriceCalculator.isMokapot(m)
        val b         = if (isMokapot) "-" else beans()
        val lk        = if (isMokapot) "-" else levelKopi()
        val le        = if (m == "Mokapot Hot") "-" else es()
        val notes     = binding.etCatatan.text.toString().trim()
        val priceItem = PriceCalculator.calculate(m, b, lk)
        val total     = priceItem * qty
        val queue     = db.nextQueueNumber()

        val t = Transaction(
            queueNumber  = queue,
            menu         = m,
            beans        = b,
            levelKopi    = lk,
            kemanisan    = gula(),
            levelEs      = le,
            qty          = qty,
            notes        = notes,
            pricePerItem = priceItem,
            totalPrice   = total
        )

        val id = db.insert(t)
        if (id <= 0) { Toast.makeText(this, "Gagal menyimpan order", Toast.LENGTH_SHORT).show(); return }

        binding.btnProses.isEnabled = false
        scope.launch {
            val printed = withContext(Dispatchers.IO) { tryPrint(t) }
            val msg = if (printed)
                "✅ Order $queue berhasil!\n${PriceCalculator.format(total)}"
            else
                "✅ Order $queue tersimpan\n⚠️ Gagal cetak — periksa printer"
            Toast.makeText(this@MainActivity, msg, Toast.LENGTH_LONG).show()
            resetForm()
            binding.btnProses.isEnabled = true
        }
    }

    private fun tryPrint(t: Transaction): Boolean {
        if (printer.isConnected()) {
            printer.printKitchen(t)
            Thread.sleep(400)
            return printer.printCustomer(t)
        }
        val addr = printer.savedAddress() ?: return false
        return try {
            val bm = getSystemService(BluetoothManager::class.java)
            @SuppressLint("MissingPermission")
            val device = bm.adapter.getRemoteDevice(addr)
            if (printer.connect(device)) {
                printer.printKitchen(t)
                Thread.sleep(400)
                printer.printCustomer(t)
            } else false
        } catch (e: Exception) { false }
    }

    private fun resetForm() {
        binding.spinnerMenu.setSelection(0)
        binding.rbRobusta.isChecked   = true
        binding.rbNormalKopi.isChecked = true
        binding.rbNormalGula.isChecked = true
        binding.rbNormalEs.isChecked   = true
        qty = 1; binding.tvQty.text = "1"
        binding.etCatatan.text?.clear()
        updatePrice()
    }

    @SuppressLint("MissingPermission")
    private fun selectPrinter() {
        if (!checkBtPermissions()) return
        val bm = getSystemService(BluetoothManager::class.java)
        val adapter = bm?.adapter
        if (adapter == null || !adapter.isEnabled) {
            Toast.makeText(this, "Bluetooth belum aktif. Aktifkan dulu.", Toast.LENGTH_SHORT).show()
            return
        }
        val paired: Set<BluetoothDevice> = adapter.bondedDevices
        if (paired.isEmpty()) {
            Toast.makeText(this, "Tidak ada perangkat paired. Pair dulu via Pengaturan Bluetooth.", Toast.LENGTH_LONG).show()
            return
        }
        val list = paired.toList()
        val names = list.map { "${it.name ?: "Unknown"}\n${it.address}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Pilih Printer Bluetooth")
            .setItems(names) { _, i ->
                val dev = list[i]
                printer.save(dev.address, dev.name ?: "Printer")
                scope.launch {
                    val ok = withContext(Dispatchers.IO) { printer.connect(dev) }
                    Toast.makeText(this@MainActivity,
                        if (ok) "✅ Terhubung ke ${dev.name}" else "❌ Gagal konek",
                        Toast.LENGTH_SHORT).show()
                    updatePrinterStatus()
                }
            }.show()
    }

    private fun updatePrinterStatus() {
        val name = printer.savedName()
        binding.tvPrinterStatus.text =
            if (name != null) "Printer: $name ${if (printer.isConnected()) "🟢" else "⚪"}"
            else "Printer: Belum dipilih"
    }

    private fun checkBtPermissions(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN),
                    BT_REQ
                )
                return false
            }
        }
        return true
    }

    override fun onRequestPermissionsResult(req: Int, perms: Array<String>, results: IntArray) {
        super.onRequestPermissionsResult(req, perms, results)
        if (req == BT_REQ && results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED)
            selectPrinter()
        else if (req == BT_REQ)
            Toast.makeText(this, "Izin Bluetooth diperlukan", Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() { super.onDestroy(); scope.cancel() }
}
