package com.doyangopi.kasir

import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.doyangopi.kasir.data.DatabaseHelper
import com.doyangopi.kasir.data.MenuItem
import com.doyangopi.kasir.databinding.ActivityMenuBinding
import com.doyangopi.kasir.util.HppManager
import com.doyangopi.kasir.util.MenuCache
import com.doyangopi.kasir.util.PriceCalculator

class MenuActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMenuBinding
    private lateinit var db: DatabaseHelper
    private lateinit var hppManager: HppManager
    private val addOnFields = mutableMapOf<String, EditText>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMenuBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.title = "Kelola Menu"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        db = DatabaseHelper(this)
        hppManager = HppManager(this)

        loadMenuList()
        buildAddOnForm()

        binding.btnAddMenu.setOnClickListener { showMenuDialog(null) }
        binding.btnSaveAddOnHpp.setOnClickListener { saveAddOnHpp() }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ══════════════════════════════════════════════════════════════
    //  MENU LIST
    // ══════════════════════════════════════════════════════════════

    private fun loadMenuList() {
        val container = binding.layoutMenuList
        container.removeAllViews()

        val items = db.getAllMenus()
        if (items.isEmpty()) {
            container.addView(TextView(this).apply {
                text = "Belum ada menu. Tap \"+ Tambah Menu Baru\"."
                setTextColor(Color.parseColor("#888888"))
                textSize = 12f
                setPadding(dp(12), dp(12), dp(12), dp(12))
            })
            return
        }

        items.forEach { item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(10), dp(6), dp(10))
            }

            val info = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            info.addView(TextView(this).apply {
                text = item.name
                setTextColor(Color.WHITE)
                textSize = 13f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
            })
            info.addView(TextView(this).apply {
                val shotInfo = if (item.allowExtraShot) "" else "  ·  no extra shot"
                text = "Jual: ${PriceCalculator.format(item.price)}   ·   HPP: ${PriceCalculator.format(item.hpp)}$shotInfo"
                setTextColor(Color.parseColor("#AAAAAA"))
                textSize = 11f
            })

            val btnEdit = TextView(this).apply {
                text = "✎"
                textSize = 18f
                setTextColor(Color.parseColor("#F5CBA7"))
                setPadding(dp(10), dp(4), dp(10), dp(4))
                setOnClickListener { showMenuDialog(item) }
            }
            val btnDelete = TextView(this).apply {
                text = "🗑"
                textSize = 16f
                setPadding(dp(10), dp(4), dp(4), dp(4))
                setOnClickListener { confirmDelete(item) }
            }

            row.addView(info)
            row.addView(btnEdit)
            row.addView(btnDelete)
            container.addView(row)

            container.addView(View(this).apply {
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1))
                setBackgroundColor(Color.parseColor("#222244"))
            })
        }
    }

    private fun confirmDelete(item: MenuItem) {
        AlertDialog.Builder(this)
            .setTitle("Hapus Menu")
            .setMessage("Hapus \"${item.name}\"? Riwayat transaksi lama tidak akan terpengaruh.")
            .setPositiveButton("Hapus") { _, _ ->
                db.deleteMenu(item.id)
                MenuCache.load(this)
                loadMenuList()
                Toast.makeText(this, "🗑 Menu dihapus", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ══════════════════════════════════════════════════════════════
    //  ADD / EDIT DIALOG
    // ══════════════════════════════════════════════════════════════

    private fun showMenuDialog(existing: MenuItem?) {
        val pad = dp(20)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, dp(8), pad, 0)
        }

        fun label(text: String) = TextView(this).apply {
            this.text = text
            setTextColor(Color.parseColor("#AAAAAA"))
            textSize = 12f
            setPadding(0, dp(10), 0, dp(2))
        }

        val etName = EditText(this).apply {
            hint = "contoh: Kopi Susu Vanilla (Ice)"
            setText(existing?.name ?: "")
            setTextColor(Color.WHITE)
        }
        val etPrice = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = "0"
            setText(if (existing != null) existing.price.toString() else "")
            setTextColor(Color.WHITE)
        }
        val etHpp = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = "0"
            setText(if (existing != null) existing.hpp.toString() else "")
            setTextColor(Color.WHITE)
        }
        val cbShot = CheckBox(this).apply {
            text = "Boleh Extra Shot"
            isChecked = existing?.allowExtraShot ?: true
            setTextColor(Color.WHITE)
        }

        container.addView(label("Nama Menu"));      container.addView(etName)
        container.addView(label("Harga Jual (Rp)")); container.addView(etPrice)
        container.addView(label("HPP / Modal (Rp)")); container.addView(etHpp)
        container.addView(cbShot.apply { setPadding(0, dp(14), 0, 0) })

        AlertDialog.Builder(this)
            .setTitle(if (existing == null) "Tambah Menu" else "Edit Menu")
            .setView(container)
            .setPositiveButton("Simpan", null) // di-override di bawah supaya validasi bisa cegah dialog nutup
            .setNegativeButton("Batal", null)
            .create()
            .apply {
                setOnShowListener {
                    getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val name  = etName.text.toString().trim()
                        val price = etPrice.text.toString().trim().toIntOrNull()
                        val hpp   = etHpp.text.toString().trim().toIntOrNull() ?: 0
                        val allowShot = cbShot.isChecked

                        when {
                            name.isBlank() -> etName.error = "Nama menu wajib diisi"
                            price == null || price <= 0 -> etPrice.error = "Harga jual wajib diisi"
                            db.isMenuNameTaken(name, existing?.id ?: -1) ->
                                etName.error = "Nama menu sudah dipakai"
                            else -> {
                                if (existing == null) {
                                    db.insertMenu(name, price, hpp, allowShot)
                                    Toast.makeText(this@MenuActivity, "✅ Menu ditambahkan", Toast.LENGTH_SHORT).show()
                                } else {
                                    db.updateMenu(existing.copy(name = name, price = price, hpp = hpp, allowExtraShot = allowShot))
                                    Toast.makeText(this@MenuActivity, "✅ Menu diperbarui", Toast.LENGTH_SHORT).show()
                                }
                                MenuCache.load(this@MenuActivity)
                                loadMenuList()
                                dismiss()
                            }
                        }
                    }
                }
            }
            .show()
    }

    // ══════════════════════════════════════════════════════════════
    //  ADD-ON HPP
    // ══════════════════════════════════════════════════════════════

    private fun buildAddOnForm() {
        val container = binding.layoutAddOnHppList
        container.removeAllViews()

        PriceCalculator.ADD_ONS.forEach { addOn ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(6), 0, dp(6))
            }
            val labelView = TextView(this).apply {
                text = "${addOn.label}  (jual +${PriceCalculator.format(addOn.price)})"
                setTextColor(Color.WHITE)
                textSize = 12f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            val prefix = TextView(this).apply {
                text = "Rp "
                setTextColor(Color.parseColor("#AAAAAA"))
                textSize = 12f
            }
            val input = EditText(this).apply {
                setText(hppManager.getAddOnHpp(addOn.label).toString())
                hint = "0"
                setHintTextColor(Color.parseColor("#666688"))
                inputType = InputType.TYPE_CLASS_NUMBER
                setTextColor(Color.WHITE)
                textSize = 13f
                gravity = Gravity.END
                layoutParams = LinearLayout.LayoutParams(dp(80), LinearLayout.LayoutParams.WRAP_CONTENT)
            }
            addOnFields[addOn.label] = input

            row.addView(labelView)
            row.addView(prefix)
            row.addView(input)
            container.addView(row)

            container.addView(View(this).apply {
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1))
                setBackgroundColor(Color.parseColor("#222244"))
            })
        }
    }

    private fun saveAddOnHpp() {
        val values = addOnFields.mapValues { (_, field) -> field.text.toString().trim().toIntOrNull() ?: 0 }
        hppManager.setAllAddOns(values)
        Toast.makeText(this, "✅ HPP add-on disimpan", Toast.LENGTH_SHORT).show()
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}
