package com.doyangopi.kasir

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.doyangopi.kasir.data.DatabaseHelper
import com.doyangopi.kasir.databinding.ActivityHistoryBinding
import com.doyangopi.kasir.util.HppManager
import com.doyangopi.kasir.util.MenuCache
import com.doyangopi.kasir.util.PriceCalculator
import com.doyangopi.kasir.util.ProfitCalculator
import java.util.Calendar

class HistoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHistoryBinding
    private lateinit var db: DatabaseHelper
    private lateinit var hppManager: HppManager
    private lateinit var adapter: HistoryAdapter

    private val hariNama = arrayOf("Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu")
    private val bulanNama = arrayOf(
        "Januari", "Februari", "Maret", "April", "Mei", "Juni",
        "Juli", "Agustus", "September", "Oktober", "November", "Desember"
    )
    private val bulanSingkat = arrayOf(
        "Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.title = "Riwayat Laporan"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        db = DatabaseHelper(this)
        hppManager = HppManager(this)
        MenuCache.load(this)

        adapter = HistoryAdapter()
        binding.rvHistory.layoutManager = LinearLayoutManager(this)
        binding.rvHistory.adapter = adapter

        binding.btnTabHarian.setOnClickListener { selectTab(true) }
        binding.btnTabBulanan.setOnClickListener { selectTab(false) }

        selectTab(true)
    }

    override fun onResume() {
        super.onResume()
        MenuCache.load(this)
    }

    private fun selectTab(daily: Boolean) {
        binding.btnTabHarian.backgroundTintList =
            getColorStateList(if (daily) R.color.coffee_gold else R.color.medium_blue)
        binding.btnTabHarian.setTextColor(getColor(if (daily) R.color.dark_navy else R.color.white))
        binding.btnTabBulanan.backgroundTintList =
            getColorStateList(if (!daily) R.color.coffee_gold else R.color.medium_blue)
        binding.btnTabBulanan.setTextColor(getColor(if (!daily) R.color.dark_navy else R.color.white))

        if (daily) loadDaily() else loadMonthly()
    }

    private fun hppMap() = MenuCache.all().associate { it.name to it.hpp }
    private fun addOnHppMap() = hppManager.getAllAddOns(PriceCalculator.ADD_ONS.map { it.label })

    // Catatan: Pengeluaran TIDAK ikut dihitung ke Omzet/HPP/Overhead/Net Profit.
    // Pengeluaran hanya ditampilkan sebagai breakdown per-hari di tab Per Bulan.
    private fun loadDaily() {
        val hpp = hppMap(); val addOn = addOnHppMap()
        val rows = db.getDistinctDayStarts().map { start ->
            val cal = Calendar.getInstance().apply { timeInMillis = start }
            val end = Calendar.getInstance().apply { timeInMillis = start; add(Calendar.DAY_OF_MONTH, 1) }.timeInMillis
            val txs = db.queryRange(start, end)
            val label = "${hariNama[cal.get(Calendar.DAY_OF_WEEK) - 1]}, ${cal.get(Calendar.DAY_OF_MONTH)} " +
                "${bulanNama[cal.get(Calendar.MONTH)]} ${cal.get(Calendar.YEAR)}"
            HistoryRow(label, txs.sumOf { it.qty }, ProfitCalculator.calculate(txs, hpp, addOn))
        }
        showRows(rows)
    }

    private fun loadMonthly() {
        val hpp = hppMap(); val addOn = addOnHppMap()
        val rows = db.getDistinctMonthStarts().map { start ->
            val cal = Calendar.getInstance().apply { timeInMillis = start }
            val end = Calendar.getInstance().apply { timeInMillis = start; add(Calendar.MONTH, 1) }.timeInMillis
            val txs = db.queryRange(start, end)
            val label = "${bulanNama[cal.get(Calendar.MONTH)]} ${cal.get(Calendar.YEAR)}"

            // Breakdown pengeluaran per-hari dalam bulan ini (tidak masuk kalkulasi profit)
            val expenses = db.getExpensesForPeriod(start, end)
            val perDay = expenses.groupBy { exp ->
                Calendar.getInstance().apply { timeInMillis = exp.timestamp }.get(Calendar.DAY_OF_MONTH)
            }.toSortedMap()
            val expenseTotal = expenses.sumOf { it.amount }
            val breakdown = perDay.entries.joinToString("\n") { (day, list) ->
                "${day} ${bulanSingkat[cal.get(Calendar.MONTH)]}: ${PriceCalculator.format(list.sumOf { it.amount })}"
            }

            HistoryRow(
                label, txs.sumOf { it.qty }, ProfitCalculator.calculate(txs, hpp, addOn),
                expenseTotal = expenseTotal, expenseBreakdown = breakdown
            )
        }
        showRows(rows)
    }

    private fun showRows(rows: List<HistoryRow>) {
        adapter.replaceAll(rows)
        binding.tvEmpty.visibility   = if (rows.isEmpty()) View.VISIBLE else View.GONE
        binding.rvHistory.visibility = if (rows.isEmpty()) View.GONE else View.VISIBLE
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}
