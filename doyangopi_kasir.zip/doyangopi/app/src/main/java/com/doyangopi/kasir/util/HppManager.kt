package com.doyangopi.kasir.util

import android.content.Context

/**
 * Menyimpan HPP (Harga Pokok Penjualan / harga modal) per add-on.
 * HPP per menu sekarang tersimpan langsung di tabel menu_items (lihat DatabaseHelper/MenuItem) —
 * jadi kelas ini hanya untuk add-on (Upsize, Oatmilk, Sauce) yang bukan baris menu tersendiri.
 * Disimpan terpisah di SharedPreferences — tidak menyentuh database transaksi.
 */
class HppManager(context: Context) {

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    companion object {
        private const val PREFS_NAME  = "doyangopi_hpp"
        private const val ADDON_PREFIX = "addon_hpp_"

        // Estimasi modal add-on (bisa diubah manual di layar Kelola Menu).
        // Upsize: tambahan cup 16oz + porsi bahan lebih banyak.
        // Oatmilk: substitusi susu, harga per porsi oat milk relatif mahal.
        // Sauce: harga pump sauce botolan per porsi.
        val DEFAULT_ADDON_HPP = mapOf(
            "Upsize (16oz)"      to 1500,
            "Oatmilk"            to 2000,
            "Caramel Sauce"      to 1000,
            "Butterscotch Sauce" to 1200
        )
    }

    // ── Add-On ──
    fun getAddOnHpp(label: String): Int =
        prefs.getInt(ADDON_PREFIX + label, DEFAULT_ADDON_HPP[label] ?: 0)

    fun setAddOnHpp(label: String, value: Int) {
        prefs.edit().putInt(ADDON_PREFIX + label, value).apply()
    }

    fun setAllAddOns(values: Map<String, Int>) {
        val editor = prefs.edit()
        values.forEach { (label, value) -> editor.putInt(ADDON_PREFIX + label, value) }
        editor.apply()
    }

    fun getAllAddOns(labels: List<String>): Map<String, Int> =
        labels.associateWith { getAddOnHpp(it) }
}
