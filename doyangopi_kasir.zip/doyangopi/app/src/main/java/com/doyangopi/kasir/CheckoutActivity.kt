package com.doyangopi.kasir

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothManager
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.doyangopi.kasir.bluetooth.BluetoothPrinter
import com.doyangopi.kasir.data.CartItem
import com.doyangopi.kasir.data.DatabaseHelper
import com.doyangopi.kasir.data.Transaction
import com.doyangopi.kasir.databinding.ActivityCheckoutBinding
import com.doyangopi.kasir.util.PriceCalculator
import kotlinx.coroutines.*

class CheckoutActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCheckoutBinding
    private lateinit var db: DatabaseHelper
    private lateinit var printer: BluetoothPrinter
    private val scope = CoroutineScope(Dispatchers.Main + Job())

    private lateinit var cartItems: List<CartItem>
    private lateinit var queueNumber: String
    private var selectedPayment = "Cash"
    private var orderTimestamp  = System.currentTimeMillis()
    private var orderSaved      = false

    companion object { private const val BT_REQ = 101 }

    @Suppress("UNCHECKED_CAST")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCheckoutBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.title = "Checkout"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        db      = DatabaseHelper(this)
        printer = BluetoothPrinter(this)

        // Ambil cart dari Intent
        cartItems = (intent.getSerializableExtra("cart") as? ArrayList<CartItem>) ?: emptyList()
        if (cartItems.isEmpty()) { finish(); return }

        // Generate queue number sekarang
        queueNumber      = db.nextQueueNumber()
        orderTimestamp   = System.currentTimeMillis()

        buildUI()
        setupListeners()
        updatePrinterStatus()
    }

    private fun buildUI() {
        binding.tvCheckoutQueue.text = "Nomor Antrian: $queueNumber"

        // Total
        val grandTotal = cartItems.sumOf { it.totalPrice }
        binding.tvCheckoutTotal.text = PriceCalculator.format(grandTotal)

        // Tambahkan item ke layout secara dinamis
        val container = binding.layoutOrderItems
        cartItems.forEachIndexed { i, item ->
            addItemView(container, i + 1, item)
            if (i < cartItems.size - 1) addDivider(container)
        }
    }

    private fun addItemView(container: LinearLayout, num: Int, item: CartItem) {
        val dp4 = (4 * resources.displayMetrics.density).toInt()
        val dp2 = (2 * resources.displayMetrics.density).toInt()

        // Menu + extra shot
        val tvMenu = TextView(this).apply {
            val shot = if (item.extraShot) " ★ Extra Shot" else ""
            text = "$num. ${item.menu}$shot  ×${item.qty}"
            setTextColor(Color.WHITE)
            textSize = 13f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(dp4, dp4, dp4, dp2)
        }
        container.addView(tvMenu)

        // Detail (kemanisan, es, notes)
        val parts = mutableListOf(item.kemanisan)
        if (item.levelEs != "-") parts.add("Es: ${item.levelEs}")
        if (item.addOns.isNotEmpty()) parts.add(item.addOns.joinToString(", "))
        if (item.notes.isNotBlank()) parts.add(item.notes)
        val tvDetail = TextView(this).apply {
            text = "    ${parts.joinToString(" · ")}"
            setTextColor(Color.parseColor("#AAAAAA"))
            textSize = 11f
            setPadding(dp4, 0, dp4, dp2)
        }
        container.addView(tvDetail)

        // Harga item
        val tvPrice = TextView(this).apply {
            text = "    ${PriceCalculator.format(item.totalPrice)}"
            setTextColor(Color.parseColor("#F5CBA7"))
            textSize = 12f
            setPadding(dp4, 0, dp4, dp4)
        }
        container.addView(tvPrice)
    }

    private fun addDivider(container: LinearLayout) {
        val v = View(this)
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 1)
        val dp8 = (8 * resources.displayMetrics.density).toInt()
        lp.setMargins(0, dp8, 0, dp8)
        v.layoutParams = lp
        v.setBackgroundColor(Color.parseColor("#334466"))
        container.addView(v)
    }

    private fun setupListeners() {
        // Tombol Cash
        binding.btnPayCash.setOnClickListener {
            selectedPayment = "Cash"
            binding.btnPayCash.backgroundTintList =
                ContextCompat.getColorStateList(this, R.color.coffee_gold)
            binding.btnPayCash.setTextColor(ContextCompat.getColor(this, R.color.dark_navy))
            binding.btnPayQris.backgroundTintList =
                ContextCompat.getColorStateList(this, R.color.medium_blue)
            binding.btnPayQris.setTextColor(Color.WHITE)
            binding.imgQris.visibility = View.GONE
        }

        // Tombol QRIS — tampilkan gambar QRIS
        binding.btnPayQris.setOnClickListener {
            selectedPayment = "QRIS"
            binding.btnPayQris.backgroundTintList =
                ContextCompat.getColorStateList(this, R.color.coffee_gold)
            binding.btnPayQris.setTextColor(ContextCompat.getColor(this, R.color.dark_navy))
            binding.btnPayCash.backgroundTintList =
                ContextCompat.getColorStateList(this, R.color.medium_blue)
            binding.btnPayCash.setTextColor(Color.WHITE)
            binding.imgQris.visibility = View.VISIBLE
        }

        // Print Customer
        binding.btnPrintCustomer.setOnClickListener {
            scope.launch {
                binding.tvPrintStatus.text = "⏳ Mencetak struk customer..."
                val ok = withContext(Dispatchers.IO) {
                    tryConnect()
                    printer.printCustomer(queueNumber, cartItems, selectedPayment, orderTimestamp)
                }
                binding.tvPrintStatus.text =
                    if (ok) "✅ Struk customer tercetak" else "❌ Gagal cetak — cek printer"
            }
        }

        // Print Kitchen
        binding.btnPrintKitchen.setOnClickListener {
            scope.launch {
                binding.tvPrintStatus.text = "⏳ Mencetak struk kitchen..."
                val ok = withContext(Dispatchers.IO) {
                    tryConnect()
                    printer.printKitchen(queueNumber, cartItems, orderTimestamp)
                }
                binding.tvPrintStatus.text =
                    if (ok) "✅ Struk kitchen tercetak" else "❌ Gagal cetak — cek printer"
            }
        }

        // Selesai — simpan ke DB
        binding.btnSelesai.setOnClickListener {
            if (orderSaved) {
                setResult(Activity.RESULT_OK)
                finish()
                return@setOnClickListener
            }
            AlertDialog.Builder(this)
                .setTitle("Simpan Order?")
                .setMessage("No: $queueNumber\n${PriceCalculator.format(cartItems.sumOf { it.totalPrice })}\nPembayaran: $selectedPayment\n\nOrder akan disimpan ke laporan.")
                .setPositiveButton("Simpan") { _, _ ->
                    saveOrder()
                    setResult(Activity.RESULT_OK)
                    finish()
                }
                .setNegativeButton("Batal", null)
                .show()
        }

        // Ganti printer
        binding.btnPrinterCO.setOnClickListener { selectPrinter() }
    }

    private fun saveOrder() {
        if (orderSaved) return
        cartItems.forEach { item ->
            val t = Transaction(
                queueNumber  = queueNumber,
                menu         = item.menu,
                kemanisan    = item.kemanisan,
                levelEs      = item.levelEs,
                extraShot    = item.extraShot,
                qty          = item.qty,
                notes        = item.notes,
                pricePerItem = item.pricePerItem,
                totalPrice   = item.totalPrice,
                paymentMethod = selectedPayment,
                timestamp    = orderTimestamp,
                addOns       = item.addOns
            )
            db.insert(t)
        }
        orderSaved = true
    }

    private fun tryConnect() {
        if (printer.isConnected()) return
        val addr = printer.savedAddress() ?: return
        try {
            val bm = getSystemService(BluetoothManager::class.java)
            @SuppressLint("MissingPermission")
            val device = bm.adapter.getRemoteDevice(addr)
            printer.connect(device)
        } catch (_: Exception) {}
    }

    @SuppressLint("MissingPermission")
    private fun selectPrinter() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN),
                BT_REQ)
            return
        }
        val bm = getSystemService(BluetoothManager::class.java)
        if (bm?.adapter?.isEnabled != true) {
            Toast.makeText(this, "Aktifkan Bluetooth dulu", Toast.LENGTH_SHORT).show(); return
        }
        val paired = bm.adapter.bondedDevices.toList()
        if (paired.isEmpty()) {
            Toast.makeText(this, "Tidak ada perangkat paired", Toast.LENGTH_SHORT).show(); return
        }
        AlertDialog.Builder(this)
            .setTitle("Pilih Printer")
            .setItems(paired.map { "${it.name}\n${it.address}" }.toTypedArray()) { _, i ->
                val dev = paired[i]
                printer.save(dev.address, dev.name ?: "Printer")
                scope.launch {
                    val ok = withContext(Dispatchers.IO) { printer.connect(dev) }
                    Toast.makeText(this@CheckoutActivity,
                        if (ok) "✅ Terhubung ke ${dev.name}" else "❌ Gagal konek",
                        Toast.LENGTH_SHORT).show()
                    updatePrinterStatus()
                }
            }.show()
    }

    private fun updatePrinterStatus() {
        val name = printer.savedName()
        binding.tvPrinterStatusCO.text =
            if (name != null) "Printer: $name ${if (printer.isConnected()) "🟢" else "⚪"}"
            else "Printer: Belum dipilih"
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
    override fun onDestroy() { super.onDestroy(); scope.cancel() }
}
