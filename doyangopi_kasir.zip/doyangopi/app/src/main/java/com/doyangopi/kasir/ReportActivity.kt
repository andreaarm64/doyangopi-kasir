package com.doyangopi.kasir

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.doyangopi.kasir.data.DatabaseHelper
import com.doyangopi.kasir.data.Transaction
import com.doyangopi.kasir.databinding.ActivityReportBinding
import com.doyangopi.kasir.util.ExcelExporter
import com.doyangopi.kasir.util.PriceCalculator
import kotlinx.coroutines.*
import java.text.SimpleDateFormat
import java.util.*

class ReportActivity : AppCompatActivity() {

    private lateinit var binding: ActivityReportBinding
    private lateinit var db: DatabaseHelper
    private val scope = CoroutineScope(Dispatchers.Main + Job())
    private var transactions: List<Transaction> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityReportBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.title = "Laporan"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        db = DatabaseHelper(this)
        loadReport()
        binding.btnExport.setOnClickListener { exportToExcel() }
    }

    private fun loadReport() {
        transactions = db.getTodayTransactions()

        val totalCups    = transactions.sumOf { it.qty }
        val totalOmzet   = transactions.sumOf { it.totalPrice }
        val totalRobusta = transactions.filter { it.beans == "Robusta" }.sumOf { it.qty }
        val totalArabica = transactions.filter { it.beans == "Arabica" }.sumOf { it.qty }

        binding.tvOmzet.text     = "Omzet: ${PriceCalculator.format(totalOmzet)}"
        binding.tvTotalCup.text  = "Total Cup  : $totalCups"
        binding.tvRobusta.text   = "Robusta    : $totalRobusta"
        binding.tvArabica.text   = "Arabica    : $totalArabica"

        val menuCount = transactions.groupBy { it.menu }
            .mapValues { e -> e.value.sumOf { it.qty } }
        binding.tvMenuBreakdown.text =
            if (menuCount.isEmpty()) "-"
            else menuCount.entries.joinToString("\n") { "  ${it.key}: ${it.value} cup" }

        val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
        binding.tvTransactionList.text =
            if (transactions.isEmpty()) "Belum ada transaksi hari ini"
            else transactions.joinToString("\n") { t ->
                "${sdf.format(Date(t.timestamp))}  ${t.queueNumber}  " +
                "${t.menu.take(16).padEnd(16)}  ${PriceCalculator.format(t.totalPrice)}"
            }
    }

    private fun exportToExcel() {
        binding.btnExport.isEnabled = false
        scope.launch {
            val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val file = withContext(Dispatchers.IO) {
                ExcelExporter.export(this@ReportActivity, transactions, dateStr)
            }
            binding.btnExport.isEnabled = true

            if (file != null && file.exists()) {
                val uri = FileProvider.getUriForFile(
                    this@ReportActivity, "${packageName}.provider", file
                )
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                startActivity(Intent.createChooser(intent, "Bagikan Laporan Excel"))
            } else {
                Toast.makeText(this@ReportActivity, "Gagal membuat file Excel", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
    override fun onDestroy() { super.onDestroy(); scope.cancel() }
}
