package com.doyangopi.kasir

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.doyangopi.kasir.data.DatabaseHelper
import com.doyangopi.kasir.data.Transaction
import com.doyangopi.kasir.databinding.ActivityReportBinding
import com.doyangopi.kasir.util.ExcelExporter
import com.doyangopi.kasir.util.PriceCalculator
import kotlinx.coroutines.*
import java.text.SimpleDateFormat
import java.util.*

class ReportActivity : AppCompatActivity() {

    private lateinit var binding: ActivityReportBinding
    private lateinit var db: DatabaseHelper
    private lateinit var adapter: TransactionAdapter
    private val scope = CoroutineScope(Dispatchers.Main + Job())
    private val transactions = mutableListOf<Transaction>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityReportBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.title = "Laporan"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        db = DatabaseHelper(this)

        setupRecyclerView()
        loadReport()

        binding.btnExport.setOnClickListener { exportToExcel() }
    }

    private fun setupRecyclerView() {
        adapter = TransactionAdapter(transactions) { transaction, position ->
            AlertDialog.Builder(this)
                .setTitle("Hapus transaksi?")
                .setMessage(
                    "${transaction.queueNumber} — ${transaction.menu}\n" +
                    "${PriceCalculator.format(transaction.totalPrice)}\n\n" +
                    "Transaksi ini akan dihapus dari laporan."
                )
                .setPositiveButton("Hapus") { _, _ ->
                    if (db.deleteTransaction(transaction.id)) {
                        adapter.removeAt(position)
                        transactions.removeAt(position)
                        updateSummary()
                        Toast.makeText(this, "✅ Transaksi dihapus", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Gagal menghapus", Toast.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("Batal", null)
                .show()
        }

        binding.rvTransactions.layoutManager = LinearLayoutManager(this)
        binding.rvTransactions.adapter = adapter
        binding.rvTransactions.isNestedScrollingEnabled = false
    }

    private fun loadReport() {
        val fresh = db.getTodayTransactions()
        transactions.clear()
        transactions.addAll(fresh)
        adapter.notifyDataSetChanged()
        updateSummary()

        if (transactions.isEmpty()) {
            binding.tvEmptyList.visibility   = View.VISIBLE
            binding.rvTransactions.visibility = View.GONE
        } else {
            binding.tvEmptyList.visibility   = View.GONE
            binding.rvTransactions.visibility = View.VISIBLE
        }
    }

    private fun updateSummary() {
        val totalCups    = transactions.sumOf { it.qty }
        val totalOmzet   = transactions.sumOf { it.totalPrice }
        val totalRobusta = transactions.filter { it.beans == "Robusta" }.sumOf { it.qty }
        val totalArabica = transactions.filter { it.beans == "Arabica" }.sumOf { it.qty }

        binding.tvOmzet.text    = "Omzet: ${PriceCalculator.format(totalOmzet)}"
        binding.tvTotalCup.text = "Total Cup  : $totalCups"
        binding.tvRobusta.text  = "Robusta    : $totalRobusta"
        binding.tvArabica.text  = "Arabica    : $totalArabica"

        val menuCount = transactions.groupBy { it.menu }
            .mapValues { e -> e.value.sumOf { it.qty } }
        binding.tvMenuBreakdown.text =
            if (menuCount.isEmpty()) "-"
            else menuCount.entries.joinToString("\n") { "  ${it.key}: ${it.value} cup" }
    }

    private fun exportToExcel() {
        binding.btnExport.isEnabled = false
        scope.launch {
            val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val file = withContext(Dispatchers.IO) {
                ExcelExporter.export(this@ReportActivity, transactions, dateStr)
            }
            binding.btnExport.isEnabled = true

            if (file != null && file.exists()) {
                val uri = FileProvider.getUriForFile(this@ReportActivity, "${packageName}.provider", file)
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                startActivity(Intent.createChooser(intent, "Bagikan Laporan Excel"))
            } else {
                Toast.makeText(this@ReportActivity, "Gagal membuat file Excel", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
    override fun onDestroy() { super.onDestroy(); scope.cancel() }
}
