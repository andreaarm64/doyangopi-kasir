package com.doyangopi.kasir

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.doyangopi.kasir.data.DatabaseHelper
import com.doyangopi.kasir.data.Transaction
import com.doyangopi.kasir.databinding.ActivityReportBinding
import com.doyangopi.kasir.util.ExcelExporter
import com.doyangopi.kasir.util.PriceCalculator
import kotlinx.coroutines.*
import java.text.SimpleDateFormat
import java.util.*

class ReportActivity : AppCompatActivity() {

    private lateinit var binding: ActivityReportBinding
    private lateinit var db: DatabaseHelper
    private lateinit var adapter: TransactionAdapter
    private val scope = CoroutineScope(Dispatchers.Main + Job())
    private val transactions = mutableListOf<Transaction>()
    private var currentPeriod = "today"

    private val DAY_NAMES = arrayOf("Min","Sen","Sel","Rab","Kam","Jum","Sab")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityReportBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.title = "Laporan"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        db = DatabaseHelper(this)
        setupRecyclerView()
        setupPeriodButtons()
        loadReport("today")

        binding.btnExport.setOnClickListener { exportToExcel() }
    }

    // ─── PERIOD SELECTOR ───────────────────────────────────────────────────

    private fun setupPeriodButtons() {
        binding.btnPeriodToday.setOnClickListener { loadReport("today") }
        binding.btnPeriodWeek.setOnClickListener  { loadReport("week")  }
        binding.btnPeriodMonth.setOnClickListener { loadReport("month") }
    }

    private fun setPeriodUI(period: String) {
        val gold  = ContextCompat.getColorStateList(this, R.color.coffee_gold)
        val blue  = ContextCompat.getColorStateList(this, R.color.medium_blue)
        val dark  = ContextCompat.getColor(this, R.color.dark_navy)
        val white = Color.WHITE

        listOf(
            binding.btnPeriodToday to "today",
            binding.btnPeriodWeek  to "week",
            binding.btnPeriodMonth to "month"
        ).forEach { (btn, p) ->
            btn.backgroundTintList = if (p == period) gold else blue
            btn.setTextColor(if (p == period) dark else white)
        }
    }

    // ─── MAIN LOAD ─────────────────────────────────────────────────────────

    private fun loadReport(period: String) {
        currentPeriod = period
        setPeriodUI(period)

        val txs = when (period) {
            "week"  -> db.getWeekTransactions()
            "month" -> db.getMonthTransactions()
            else    -> db.getTodayTransactions()
        }

        transactions.clear()
        transactions.addAll(txs)
        if (period == "today") adapter.notifyDataSetChanged()

        updateSummary(txs)
        buildHourlyChart(txs)
        buildMenuRanking(txs)

        when (period) {
            "today" -> {
                binding.tvBreakdownHeader.visibility = View.GONE
                binding.cardBreakdown.visibility     = View.GONE
                binding.tvTransHeader.visibility     = View.VISIBLE
                binding.cardTransactions.visibility  = View.VISIBLE
                binding.tvEmptyList.visibility  = if (txs.isEmpty()) View.VISIBLE else View.GONE
                binding.rvTransactions.visibility = if (txs.isEmpty()) View.GONE else View.VISIBLE
            }
            "week" -> {
                binding.tvBreakdownHeader.text       = "  📅 RINCIAN HARIAN"
                binding.tvBreakdownHeader.visibility = View.VISIBLE
                binding.cardBreakdown.visibility     = View.VISIBLE
                binding.tvTransHeader.visibility     = View.GONE
                binding.cardTransactions.visibility  = View.GONE
                buildDayBreakdown(txs)
            }
            "month" -> {
                binding.tvBreakdownHeader.text       = "  📅 RINCIAN MINGGUAN"
                binding.tvBreakdownHeader.visibility = View.VISIBLE
                binding.cardBreakdown.visibility     = View.VISIBLE
                binding.tvTransHeader.visibility     = View.GONE
                binding.cardTransactions.visibility  = View.GONE
                buildWeekBreakdown(txs)
            }
        }
    }

    // ─── SUMMARY ───────────────────────────────────────────────────────────

    private fun updateSummary(txs: List<Transaction>) {
        val totalOmzet  = txs.sumOf { it.totalPrice }
        val totalCups   = txs.sumOf { it.qty }
        val totalOrders = txs.map { it.queueNumber }.distinct().size
        val cashOmzet   = txs.filter { it.paymentMethod == "Cash" }.sumOf { it.totalPrice }
        val qrisOmzet   = txs.filter { it.paymentMethod == "QRIS" }.sumOf { it.totalPrice }
        val extraShotCt = txs.filter { it.extraShot }.sumOf { it.qty }

        val periodLabel = when(currentPeriod) { "week" -> "Minggu Ini" "month" -> "Bulan Ini" else -> "Hari Ini" }
        binding.tvOmzet.text     = "${PriceCalculator.format(totalOmzet)}"
        binding.tvTotalCup.text  = "☕ $totalCups cup"
        binding.tvOrders.text    = "🧾 $totalOrders pesanan"
        binding.tvRobusta.text   = "💵 Cash: ${PriceCalculator.format(cashOmzet)}"
        binding.tvArabica.text   = "📱 QRIS: ${PriceCalculator.format(qrisOmzet)}"
        binding.tvExtraShot.text = if (extraShotCt > 0)
            "★ Extra Shot: $extraShotCt kali (${(extraShotCt * 100f / totalCups.coerceAtLeast(1)).toInt()}% dari total cup)"
            else ""
    }

    // ─── GRAFIK PER JAM ────────────────────────────────────────────────────

    private fun buildHourlyChart(txs: List<Transaction>) {
        val container = binding.layoutHourlyChart
        container.removeAllViews()

        if (txs.isEmpty()) { addEmptyLabel(container, "Belum ada data"); return }

        val sdfHour = SimpleDateFormat("H", Locale.getDefault())
        val hourly = txs.groupBy { sdfHour.format(Date(it.timestamp)).toInt() }
            .mapValues { e -> e.value.sumOf { it.qty } }
            .toSortedMap()

        val maxQty = hourly.values.maxOrNull() ?: 1
        val screenW = resources.displayMetrics.widthPixels
        val maxBarW = (screenW * 0.52f).toInt()

        hourly.forEach { (hour, qty) ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = llParams(matchParent = true, h = dp(28), bMargin = dp(3))
            }

            // Jam label
            row.addView(TextView(this).apply {
                text = String.format("%02d:00", hour)
                setTextColor(Color.parseColor("#AAAAAA"))
                textSize = 11f
                layoutParams = LinearLayout.LayoutParams(dp(52), lp_wrap)
            })

            // Bar
            row.addView(View(this).apply {
                setBackgroundColor(Color.parseColor("#F5CBA7"))
                val bw = ((qty.toFloat() / maxQty) * maxBarW).toInt().coerceAtLeast(dp(4))
                layoutParams = LinearLayout.LayoutParams(bw, dp(14)).apply { marginEnd = dp(8) }
            })

            // Qty
            row.addView(TextView(this).apply {
                text = "$qty cup"
                setTextColor(Color.WHITE)
                textSize = 11f
                layoutParams = LinearLayout.LayoutParams(lp_wrap, lp_wrap)
            })

            // Peak badge
            if (qty == maxQty && maxQty > 0) {
                row.addView(TextView(this).apply {
                    text = "  🔥 Ramai"
                    setTextColor(Color.parseColor("#FF9944"))
                    textSize = 10f
                    layoutParams = LinearLayout.LayoutParams(lp_wrap, lp_wrap)
                })
            }
            container.addView(row)
        }
    }

    // ─── RANKING MENU ──────────────────────────────────────────────────────

    private fun buildMenuRanking(txs: List<Transaction>) {
        val container = binding.layoutMenuRanking
        container.removeAllViews()

        if (txs.isEmpty()) { addEmptyLabel(container, "Belum ada data"); return }

        val ranked = txs.groupBy { it.menu }
            .mapValues { e -> e.value.sumOf { it.qty } }
            .entries.sortedByDescending { it.value }

        val maxQty = ranked.firstOrNull()?.value ?: 1
        val screenW = resources.displayMetrics.widthPixels
        val maxBarW = (screenW * 0.45f).toInt()
        val medals  = listOf("🥇", "🥈", "🥉")
        val barColors = listOf("#F5CBA7", "#C0C0C0", "#CD7F32")

        ranked.forEachIndexed { i, (menu, qty) ->
            val col   = if (i < barColors.size) Color.parseColor(barColors[i]) else Color.parseColor("#556688")
            val medal = if (i < medals.size) medals[i] else "${i + 1}."
            val omzet = txs.filter { it.menu == menu }.sumOf { it.totalPrice }

            // Baris nama menu
            val tvMenu = TextView(this).apply {
                text = "$medal  $menu"
                setTextColor(if (i == 0) Color.parseColor("#F5CBA7") else Color.WHITE)
                textSize = 13f
                if (i == 0) setTypeface(null, Typeface.BOLD)
                layoutParams = llParams(matchParent = true, bMargin = dp(3))
            }
            container.addView(tvMenu)

            // Bar + qty + omzet
            val barRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = llParams(matchParent = true, bMargin = dp(10))
            }
            val bw = ((qty.toFloat() / maxQty) * maxBarW).toInt().coerceAtLeast(dp(6))
            barRow.addView(View(this).apply {
                setBackgroundColor(col)
                layoutParams = LinearLayout.LayoutParams(bw, dp(10)).apply { marginEnd = dp(8) }
            })
            barRow.addView(TextView(this).apply {
                text = "$qty cup  ·  ${PriceCalculator.format(omzet)}"
                setTextColor(Color.parseColor("#AAAAAA"))
                textSize = 11f
            })
            container.addView(barRow)
        }
    }

    // ─── RINCIAN HARIAN (Minggu) ───────────────────────────────────────────

    private fun buildDayBreakdown(txs: List<Transaction>) {
        val container = binding.layoutBreakdown
        container.removeAllViews()

        if (txs.isEmpty()) { addEmptyLabel(container, "Belum ada transaksi minggu ini"); return }

        val sdfDate = SimpleDateFormat("dd/MM", Locale.getDefault())
        val dailyMap = txs.groupBy {
            val c = Calendar.getInstance().apply { timeInMillis = it.timestamp }
            c.get(Calendar.DAY_OF_YEAR)
        }.toSortedMap()

        dailyMap.forEach { (_, dayTxs) ->
            val cal    = Calendar.getInstance().apply { timeInMillis = dayTxs.first().timestamp }
            val dayStr = DAY_NAMES[cal.get(Calendar.DAY_OF_WEEK) - 1]
            val dateStr = sdfDate.format(cal.time)
            val omzet  = dayTxs.sumOf { it.totalPrice }
            val cups   = dayTxs.sumOf { it.qty }
            val orders = dayTxs.map { it.queueNumber }.distinct().size

            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = llParams(matchParent = true, bMargin = dp(8))
            }
            row.addView(TextView(this).apply {
                text = "$dayStr $dateStr"
                setTextColor(Color.WHITE); textSize = 12f
                layoutParams = LinearLayout.LayoutParams(0, lp_wrap, 1.8f)
            })
            row.addView(TextView(this).apply {
                text = PriceCalculator.format(omzet)
                setTextColor(Color.parseColor("#F5CBA7")); textSize = 12f; setTypeface(null, Typeface.BOLD)
                gravity = Gravity.END
                layoutParams = LinearLayout.LayoutParams(0, lp_wrap, 1.6f)
            })
            row.addView(TextView(this).apply {
                text = "$cups cup · $orders ord"
                setTextColor(Color.parseColor("#AAAAAA")); textSize = 10f
                gravity = Gravity.END
                layoutParams = LinearLayout.LayoutParams(lp_wrap, lp_wrap).apply { marginStart = dp(6) }
            })
            container.addView(row)
            container.addView(divider())
        }
    }

    // ─── RINCIAN MINGGUAN (Bulan) ──────────────────────────────────────────

    private fun buildWeekBreakdown(txs: List<Transaction>) {
        val container = binding.layoutBreakdown
        container.removeAllViews()

        if (txs.isEmpty()) { addEmptyLabel(container, "Belum ada transaksi bulan ini"); return }

        val weekMap = txs.groupBy {
            val c = Calendar.getInstance().apply { timeInMillis = it.timestamp }
            c.get(Calendar.WEEK_OF_MONTH)
        }.toSortedMap()

        weekMap.forEach { (week, weekTxs) ->
            val omzet  = weekTxs.sumOf { it.totalPrice }
            val cups   = weekTxs.sumOf { it.qty }
            val orders = weekTxs.map { it.queueNumber }.distinct().size

            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = llParams(matchParent = true, bMargin = dp(8))
            }
            row.addView(TextView(this).apply {
                text = "Minggu ke-$week"
                setTextColor(Color.WHITE); textSize = 12f
                layoutParams = LinearLayout.LayoutParams(0, lp_wrap, 1.5f)
            })
            row.addView(TextView(this).apply {
                text = PriceCalculator.format(omzet)
                setTextColor(Color.parseColor("#F5CBA7")); textSize = 12f; setTypeface(null, Typeface.BOLD)
                gravity = Gravity.END
                layoutParams = LinearLayout.LayoutParams(0, lp_wrap, 1.6f)
            })
            row.addView(TextView(this).apply {
                text = "$cups cup\n$orders pesanan"
                setTextColor(Color.parseColor("#AAAAAA")); textSize = 10f; gravity = Gravity.END
                layoutParams = LinearLayout.LayoutParams(lp_wrap, lp_wrap).apply { marginStart = dp(6) }
            })
            container.addView(row)
            container.addView(divider())
        }
    }

    // ─── RECYCLERVIEW (Today only) ─────────────────────────────────────────

    private fun setupRecyclerView() {
        adapter = TransactionAdapter(transactions) { t, pos ->
            AlertDialog.Builder(this)
                .setTitle("Hapus item ini?")
                .setMessage("${t.queueNumber} — ${t.menu}\n${PriceCalculator.format(t.totalPrice)}")
                .setPositiveButton("Hapus") { _, _ ->
                    if (db.deleteTransaction(t.id)) {
                        transactions.removeAt(pos); adapter.notifyItemRemoved(pos)
                        updateSummary(transactions)
                        buildHourlyChart(transactions)
                        buildMenuRanking(transactions)
                        Toast.makeText(this, "✅ Item dihapus", Toast.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("Batal", null).show()
        }
        binding.rvTransactions.layoutManager = LinearLayoutManager(this)
        binding.rvTransactions.adapter = adapter
        binding.rvTransactions.isNestedScrollingEnabled = false
    }

    // ─── EXPORT ────────────────────────────────────────────────────────────

    private fun exportToExcel() {
        binding.btnExport.isEnabled = false
        scope.launch {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val label = when(currentPeriod) {
                "week"  -> "minggu_${sdf.format(Date())}"
                "month" -> "bulan_${SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(Date())}"
                else    -> sdf.format(Date())
            }
            val file = withContext(Dispatchers.IO) {
                ExcelExporter.export(this@ReportActivity, transactions, label)
            }
            binding.btnExport.isEnabled = true
            if (file != null && file.exists()) {
                val uri = FileProvider.getUriForFile(this@ReportActivity, "${packageName}.provider", file)
                startActivity(Intent.createChooser(
                    Intent(Intent.ACTION_SEND).apply {
                        type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }, "Bagikan Laporan Excel"
                ))
            } else {
                Toast.makeText(this@ReportActivity, "Gagal membuat Excel", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ─── HELPERS ────────────────────────────────────────────────────────────

    private fun dp(n: Int) = (n * resources.displayMetrics.density + 0.5f).toInt()
    private val lp_wrap = LinearLayout.LayoutParams.WRAP_CONTENT
    private val matchParent = LinearLayout.LayoutParams.MATCH_PARENT

    private fun llParams(matchParent: Boolean = false, h: Int = lp_wrap, bMargin: Int = 0) =
        LinearLayout.LayoutParams(
            if (matchParent) this.matchParent else lp_wrap, h
        ).apply { bottomMargin = bMargin }

    private fun addEmptyLabel(container: LinearLayout, msg: String) {
        container.addView(TextView(this).apply {
            text = msg; setTextColor(Color.parseColor("#888888"))
            textSize = 12f; gravity = Gravity.CENTER
            layoutParams = llParams(matchParent = true, bMargin = dp(4))
        })
    }

    private fun divider(): View = View(this).apply {
        setBackgroundColor(Color.parseColor("#2A2A4A"))
        layoutParams = LinearLayout.LayoutParams(
            this@ReportActivity.matchParent, 1
        ).apply { bottomMargin = dp(8) }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
    override fun onDestroy() { super.onDestroy(); scope.cancel() }
}
