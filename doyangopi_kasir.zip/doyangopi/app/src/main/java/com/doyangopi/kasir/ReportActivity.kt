package com.doyangopi.kasir

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.doyangopi.kasir.data.DatabaseHelper
import com.doyangopi.kasir.data.Transaction
import com.doyangopi.kasir.databinding.ActivityReportBinding
import com.doyangopi.kasir.util.ExcelExporter
import com.doyangopi.kasir.util.PriceCalculator
import kotlinx.coroutines.*
import java.text.SimpleDateFormat
import java.util.*

class ReportActivity : AppCompatActivity() {

    private lateinit var binding: ActivityReportBinding
    private lateinit var db: DatabaseHelper
    private lateinit var adapter: TransactionAdapter
    private val scope = CoroutineScope(Dispatchers.Main + Job())
    private val transactions = mutableListOf<Transaction>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityReportBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.title = "Laporan Hari Ini"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        db = DatabaseHelper(this)
        setupRecyclerView()
        loadReport()
        binding.btnExport.setOnClickListener { exportToExcel() }
    }

    private fun setupRecyclerView() {
        adapter = TransactionAdapter(transactions) { t, pos ->
            AlertDialog.Builder(this)
                .setTitle("Hapus item ini?")
                .setMessage("${t.queueNumber} — ${t.menu}\n${PriceCalculator.format(t.totalPrice)}\n\nItem ini akan dihapus dari laporan.")
                .setPositiveButton("Hapus") { _, _ ->
                    if (db.deleteTransaction(t.id)) {
                        transactions.removeAt(pos)
                        adapter.notifyItemRemoved(pos)
                        updateSummary()
                        Toast.makeText(this, "✅ Item dihapus", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Gagal menghapus", Toast.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("Batal", null).show()
        }
        binding.rvTransactions.layoutManager = LinearLayoutManager(this)
        binding.rvTransactions.adapter = adapter
        binding.rvTransactions.isNestedScrollingEnabled = false
    }

    private fun loadReport() {
        val fresh = db.getTodayTransactions()
        transactions.clear()
        transactions.addAll(fresh)
        adapter.notifyDataSetChanged()
        updateSummary()
        binding.tvEmptyList.visibility    = if (transactions.isEmpty()) View.VISIBLE else View.GONE
        binding.rvTransactions.visibility = if (transactions.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun updateSummary() {
        val totalCups   = transactions.sumOf { it.qty }
        val totalOmzet  = transactions.sumOf { it.totalPrice }
        val totalOrders = transactions.map { it.queueNumber }.distinct().size
        val cashOmzet   = transactions.filter { it.paymentMethod == "Cash" }.sumOf { it.totalPrice }
        val qrisOmzet   = transactions.filter { it.paymentMethod == "QRIS" }.sumOf { it.totalPrice }

        binding.tvOmzet.text    = "Omzet: ${PriceCalculator.format(totalOmzet)}"
        binding.tvTotalCup.text = "Total Pesanan : $totalOrders  (${totalCups} cup)"
        binding.tvRobusta.text  = "Cash  : ${PriceCalculator.format(cashOmzet)}"
        binding.tvArabica.text  = "QRIS  : ${PriceCalculator.format(qrisOmzet)}"

        val menuCount = transactions.groupBy { it.menu }
            .mapValues { e -> e.value.sumOf { it.qty } }
        binding.tvMenuBreakdown.text =
            if (menuCount.isEmpty()) "-"
            else menuCount.entries.joinToString("\n") { "  ${it.key}: ${it.value} cup" }
    }

    private fun exportToExcel() {
        binding.btnExport.isEnabled = false
        scope.launch {
            val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val file = withContext(Dispatchers.IO) {
                ExcelExporter.export(this@ReportActivity, transactions, dateStr)
            }
            binding.btnExport.isEnabled = true
            if (file != null && file.exists()) {
                val uri = FileProvider.getUriForFile(this@ReportActivity, "${packageName}.provider", file)
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                startActivity(Intent.createChooser(intent, "Bagikan Laporan Excel"))
            } else {
                Toast.makeText(this@ReportActivity, "Gagal membuat file Excel", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
    override fun onDestroy() { super.onDestroy(); scope.cancel() }
}
