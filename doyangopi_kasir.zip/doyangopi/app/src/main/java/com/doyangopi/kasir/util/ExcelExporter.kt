package com.doyangopi.kasir.util

import android.content.Context
import com.doyangopi.kasir.data.Transaction
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object ExcelExporter {

    fun export(context: Context, transactions: List<Transaction>, dateStr: String): File? {
        return try {
            val dir = File(context.getExternalFilesDir(null), "exports").also { it.mkdirs() }
            val file = File(dir, "laporan_$dateStr.xlsx")
            val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())

            val strings = mutableListOf<String>()
            fun si(s: String): Int {
                val i = strings.indexOf(s)
                return if (i >= 0) i else { strings.add(s); strings.size - 1 }
            }

            val sb = StringBuilder()
            var row = 1

            // Header row
            val headers = listOf("Jam","No","Menu","Beans","Kopi","Gula","Es","Qty","Catatan","Harga/item","Total")
            sb.append("<row r=\"$row\">")
            headers.forEachIndexed { c, h ->
                sb.append("<c r=\"${col(c)}$row\" t=\"s\"><v>${si(h)}</v></c>")
            }
            sb.append("</row>"); row++

            // Data rows
            transactions.forEach { t ->
                val cells = listOf(
                    sdf.format(Date(t.timestamp)), t.queueNumber, t.menu,
                    t.beans, t.levelKopi, t.kemanisan, t.levelEs,
                    t.qty.toString(), t.notes,
                    t.pricePerItem.toString(), t.totalPrice.toString()
                )
                sb.append("<row r=\"$row\">")
                cells.forEachIndexed { c, v ->
                    val isNum = c in listOf(7, 9, 10)
                    if (isNum) sb.append("<c r=\"${col(c)}$row\"><v>$v</v></c>")
                    else sb.append("<c r=\"${col(c)}$row\" t=\"s\"><v>${si(v)}</v></c>")
                }
                sb.append("</row>"); row++
            }

            // Summary
            row++
            val totalCups   = transactions.sumOf { it.qty }
            val totalOmzet  = transactions.sumOf { it.totalPrice }
            val totalRobusta = transactions.filter { it.beans == "Robusta" }.sumOf { it.qty }
            val totalArabica = transactions.filter { it.beans == "Arabica" }.sumOf { it.qty }

            fun summaryRow(label: String, value: String) {
                sb.append("<row r=\"$row\">")
                sb.append("<c r=\"A$row\" t=\"s\"><v>${si(label)}</v></c>")
                sb.append("<c r=\"B$row\"><v>$value</v></c>")
                sb.append("</row>"); row++
            }
            summaryRow("Total Cup", totalCups.toString())
            summaryRow("Robusta", totalRobusta.toString())
            summaryRow("Arabica", totalArabica.toString())
            summaryRow("Total Omzet", totalOmzet.toString())

            row++
            sb.append("<row r=\"$row\"><c r=\"A$row\" t=\"s\"><v>${si("Per Menu")}</v></c></row>"); row++
            transactions.groupBy { it.menu }
                .mapValues { e -> e.value.sumOf { it.qty } }
                .forEach { (menu, cnt) ->
                    sb.append("<row r=\"$row\">")
                    sb.append("<c r=\"A$row\" t=\"s\"><v>${si(menu)}</v></c>")
                    sb.append("<c r=\"B$row\"><v>$cnt</v></c>")
                    sb.append("</row>"); row++
                }

            val sharedXml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="${strings.size}" uniqueCount="${strings.size}">
${strings.joinToString("\n") { "<si><t>${it.replace("&","&amp;").replace("<","&lt;")}</t></si>" }}
</sst>"""

            val sheetXml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<sheetData>$sb</sheetData></worksheet>"""

            val wbXml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"
          xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheets><sheet name="Laporan" sheetId="1" r:id="rId1"/></sheets></workbook>"""

            val wbRels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/>
</Relationships>"""

            val ct = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
<Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>
</Types>"""

            val rootRels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>"""

            ZipOutputStream(FileOutputStream(file)).use { z ->
                fun add(name: String, content: String) {
                    z.putNextEntry(ZipEntry(name))
                    z.write(content.toByteArray(Charsets.UTF_8))
                    z.closeEntry()
                }
                add("[Content_Types].xml", ct)
                add("_rels/.rels", rootRels)
                add("xl/workbook.xml", wbXml)
                add("xl/_rels/workbook.xml.rels", wbRels)
                add("xl/worksheets/sheet1.xml", sheetXml)
                add("xl/sharedStrings.xml", sharedXml)
            }
            file
        } catch (e: Exception) { e.printStackTrace(); null }
    }

    private fun col(index: Int): String = ('A' + index).toString()
}
