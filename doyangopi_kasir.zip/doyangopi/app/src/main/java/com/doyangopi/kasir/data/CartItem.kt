package com.doyangopi.kasir.data

import java.io.Serializable

data class CartItem(
    val menu: String,
    val kemanisan: String,
    val levelEs: String,
    val extraShot: Boolean,
    val qty: Int,
    val notes: String,
    val pricePerItem: Int,
    val totalPrice: Int,
    val addOns: List<String> = emptyList()
) : Serializable
