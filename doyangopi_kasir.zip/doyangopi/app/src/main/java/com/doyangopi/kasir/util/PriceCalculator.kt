package com.doyangopi.kasir.util

object PriceCalculator {

    fun isMokapot(menu: String) = menu.startsWith("Mokapot")

    fun calculate(menu: String, beans: String, levelKopi: String): Int = when (menu) {
        "Es Kopi Susu" -> when (beans) {
            "Arabica" -> if (levelKopi == "Strong") 16000 else 13000
            else      -> if (levelKopi == "Strong") 12000 else 10000
        }
        "Es Kopi Latte" -> when (beans) {
            "Arabica" -> 15000
            else      -> 12000
        }
        "Es Kopi Hitam" -> when (beans) {
            "Arabica" -> if (levelKopi == "Strong") 14000 else 11000
            else      -> if (levelKopi == "Strong") 10000 else  8000
        }
        "Mokapot Ice", "Mokapot Hot" -> 12000
        else -> 0
    }

    fun format(price: Int): String =
        "Rp " + String.format("%,d", price).replace(',', '.')
}
