package com.doyangopi.kasir.util

object PriceCalculator {

    const val EXTRA_SHOT_PRICE = 4000
    const val UPSIZE_PRICE     = 6000
    const val OATMILK_PRICE    = 3000
    const val CARAMEL_SAUCE_PRICE     = 3000
    const val BUTTERSCOTCH_SAUCE_PRICE = 5000

    // ── Menu master list (dari database, lewat MenuCache) ─────────────────
    // Panggil MenuCache.load(context) di onCreate/onResume sebelum memakai ini.
    val ALL_MENUS: List<String> get() = MenuCache.names()

    fun getBasePrice(menu: String): Int = MenuCache.get(menu)?.price ?: 0

    fun isHot(menu: String) = menu.endsWith("(Hot)")

    fun allowsExtraShot(menu: String): Boolean = MenuCache.get(menu)?.allowExtraShot ?: true

    // ── Add-on (berlaku untuk semua menu) ─────────────────────────────────
    data class AddOn(val label: String, val price: Int)

    val ADD_ONS = listOf(
        AddOn("Upsize (16oz)",       UPSIZE_PRICE),
        AddOn("Oatmilk",             OATMILK_PRICE),
        AddOn("Caramel Sauce",       CARAMEL_SAUCE_PRICE),
        AddOn("Butterscotch Sauce",  BUTTERSCOTCH_SAUCE_PRICE)
    )

    fun addOnsPrice(addOns: List<String>): Int =
        addOns.sumOf { label -> ADD_ONS.find { it.label == label }?.price ?: 0 }

    fun pricePerItem(menu: String, extraShot: Boolean, addOns: List<String> = emptyList()): Int {
        val extra = if (extraShot && allowsExtraShot(menu)) EXTRA_SHOT_PRICE else 0
        return getBasePrice(menu) + extra + addOnsPrice(addOns)
    }

    fun calculate(menu: String, extraShot: Boolean, qty: Int, addOns: List<String> = emptyList()): Int =
        pricePerItem(menu, extraShot, addOns) * qty

    fun format(price: Int): String =
        "Rp " + String.format("%,d", price).replace(',', '.')
}
