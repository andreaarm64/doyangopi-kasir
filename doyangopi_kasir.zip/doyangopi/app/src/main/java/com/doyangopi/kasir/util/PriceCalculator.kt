package com.doyangopi.kasir.util

object PriceCalculator {

    const val EXTRA_SHOT_PRICE = 4000

    private fun basePrice(menu: String): Int = when (menu) {
        "Es Kopi Susu Gula Aren" -> 10000
        "Es Kopi Latte"          -> 10000
        "Es Kopi Hitam"          -> 8000
        "Mokapot Ice",
        "Mokapot Hot"            -> 12000
        else                     -> 0
    }

    fun isMokapot(menu: String) = menu.startsWith("Mokapot")

    fun pricePerItem(menu: String, extraShot: Boolean): Int {
        val extra = if (extraShot && !isMokapot(menu)) EXTRA_SHOT_PRICE else 0
        return basePrice(menu) + extra
    }

    fun calculate(menu: String, extraShot: Boolean, qty: Int): Int =
        pricePerItem(menu, extraShot) * qty

    fun format(price: Int): String =
        "Rp " + String.format("%,d", price).replace(',', '.')
}
