package com.doyangopi.kasir.util

object PriceCalculator {

    const val EXTRA_SHOT_PRICE = 4000

    fun getBasePrice(menu: String): Int = when (menu) {
        "Es Kopi Susu Gula Aren" -> 10000
        "Es Kopi Latte"          -> 10000
        "Es Kopi Hitam"          -> 10000   // updated 8k → 10k
        "Mokapot Ice",
        "Mokapot Hot"            -> 12000
        "Es Matcha Latte"        -> 15000
        "Choco Latte"            -> 15000
        else                     -> 0
    }

    fun isMokapot(menu: String) = menu.startsWith("Mokapot")

    // Mokapot, Matcha & Choco Latte tidak ada extra shot
    fun allowsExtraShot(menu: String) =
        !isMokapot(menu) && menu != "Es Matcha Latte" && menu != "Choco Latte"

    fun pricePerItem(menu: String, extraShot: Boolean): Int {
        val extra = if (extraShot && allowsExtraShot(menu)) EXTRA_SHOT_PRICE else 0
        return getBasePrice(menu) + extra
    }

    fun calculate(menu: String, extraShot: Boolean, qty: Int): Int =
        pricePerItem(menu, extraShot) * qty

    fun format(price: Int): String =
        "Rp " + String.format("%,d", price).replace(',', '.')
}
