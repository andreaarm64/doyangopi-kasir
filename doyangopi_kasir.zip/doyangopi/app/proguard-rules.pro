# ProGuard rules for DoyangOpi
-keep class com.doyangopi.kasir.** { *; }
