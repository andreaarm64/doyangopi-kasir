# DOYANGOPI — Aplikasi Kasir Android

Aplikasi POS (Point of Sale) untuk kedai kopi dengan cetak Bluetooth ESC/POS
dan ekspor laporan harian ke Excel.

---

## FITUR
- Order kopi dengan pilihan menu, beans, level, kemanisan, es
- Nomor antrian otomatis (A001, A002, ...)
- Cetak struk Kitchen + Customer via Bluetooth (ESC/POS)
- Database lokal di HP (SQLite)
- Laporan harian + ekspor Excel (.xlsx)

---

## CARA BUILD APK

### Prasyarat
1. Install **Android Studio** (gratis): https://developer.android.com/studio
2. Saat pertama buka Android Studio, biarkan dia download SDK otomatis

### Langkah Build
1. Buka Android Studio → **File → Open** → pilih folder `doyangopi`
2. Tunggu Gradle sync selesai (butuh internet, 2-5 menit pertama kali)
3. Pilih menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**
4. Klik **locate** di notifikasi bawah untuk menemukan file APK
5. APK ada di: `app/build/outputs/apk/debug/app-debug.apk`

---

## CARA INSTALL APK KE HP
1. Copy `app-debug.apk` ke HP via USB / WhatsApp ke diri sendiri
2. Di HP: **Pengaturan → Keamanan → Izinkan install dari sumber tidak dikenal**
3. Buka file APK → Install

---

## CARA PAIRING PRINTER BLUETOOTH (RPP02N)
1. Nyalakan printer RPP02N
2. Di HP: **Pengaturan → Bluetooth → Scan & Pair** dengan RPP02N
3. Buka app Doyangopi
4. Tekan tombol **"Pilih Printer Bluetooth"**
5. Pilih RPP02N dari daftar
6. App akan test koneksi otomatis

---

## STRUKTUR HARGA
| Menu           | Beans   | Normal  | Strong  |
|----------------|---------|---------|---------|
| Es Kopi Susu   | Robusta | 10.000  | 12.000  |
| Es Kopi Susu   | Arabica | 13.000  | 16.000  |
| Es Kopi Latte  | Robusta | 12.000  | -       |
| Es Kopi Latte  | Arabica | 15.000  | -       |
| Es Kopi Hitam  | Robusta |  8.000  | 10.000  |
| Es Kopi Hitam  | Arabica | 11.000  | 14.000  |
| Mokapot Ice/Hot| -       | 12.000  | -       |

